INSERT INTO companies (company_id, company_name)
VALUES (nextval('companies_seq'), 'Vista')
ON CONFLICT(company_name) do nothing;

INSERT INTO users (user_id, login, nickname, password, role)
VALUES (nextval('users_seq'), 'Adm','Main Admin','$2a$10$s3Nj6Pfq55Dn0yF5rxKHyuMiYgtXqjNSxF.acceLGm7wNsJMub9fC', 'Admin')
ON CONFLICT(login) do nothing;