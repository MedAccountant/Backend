package com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork

import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManageLoadedData.DocType
import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import com.ClinicBackend.demo.Entities.ManagePositions.PositionData
import com.ClinicBackend.demo.Repos.PositionDataRepos
import jakarta.transaction.Transactional
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import java.time.LocalDate
import java.time.LocalDateTime

@Component
class PositionDataDAO {
    @Autowired
    private lateinit var positionDataRepos:PositionDataRepos

    fun getNewPositionsOfDepartmentsList(departments: Set<Department>):List<PositionData>{
        return positionDataRepos.findAllByProcessedMarkerEqualsAndLoadedData_DocumentTypeInAndLoadedData_DepartmentIn(false,
            setOf(DocType.ActualData, DocType.AdmissionData),departments
        )
    }

    fun getEqualPositionsData(positionData: PositionData, departments: List<Department>)=positionDataRepos
        .findAllByProcessedMarkerEqualsAndNameAndLoadedData_DepartmentIn(
            false,
            positionData.name!!,
            departments.toSet()).filter {it.attributes==positionData.attributes}

    fun getProcessedEqualPositionsData(positionData: PositionData, departments: List<Department>)=positionDataRepos
        .findAllByProcessedMarkerEqualsAndNameAndLoadedData_DepartmentIn(
            true,
            positionData.name!!,
            departments.toSet()).filter {it.attributes==positionData.attributes}

    fun getPositionDataById(id:Long): PositionData =positionDataRepos.findById(id).orElseThrow()

    fun getCurrentPositionStatistic(currentPosition: CurrentPosition):List<Pair<LocalDateTime,Long>>{
        val equalOldPositionData = positionDataRepos
            .findAllByProcessedMarkerEqualsAndNameAndLoadedData_DepartmentIn(
                true,
                currentPosition.name!!,
                setOf(currentPosition.department!!)).filter {!it.rejectedMarker &&it.attributes==currentPosition.attributes}
            .sortedBy { it.loadedData!!.uploadDateTime }

        var currentCount=0L
        val statisticList:MutableList<Pair<LocalDateTime,Long>> = mutableListOf()
        for(position in equalOldPositionData){
            currentCount=when(position.loadedData!!.documentType){
                DocType.ActualData->position.count!!
                DocType.AdmissionData->currentCount+position.count!!
                DocType.WriteOffData -> currentCount-position.count!!
                else -> throw RuntimeException("unknown document type")
            }
            statisticList.add(Pair(position.loadedData!!.uploadDateTime!!, currentCount))
        }
        return statisticList
    }

    @Transactional
    fun savePositionsData(positions:List<PositionData>){
        positionDataRepos.saveAll(positions)
    }
}