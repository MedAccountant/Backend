package com.ClinicBackend.demo.Entities.ManagePositions

import com.ClinicBackend.demo.Entities.Company
import jakarta.persistence.*

@Entity
@Table(name="unique_positions")
open class UniquePosition() {

    constructor(positionData: PositionData):this(){
        name=positionData.name
        attributes=positionData.attributes
    }

    //to make new unique position for added new (in global) current position
    constructor(currentPosition: CurrentPosition):this(){
        name=currentPosition.name
        company=currentPosition.department!!.company
        attributes=currentPosition.attributes.map {attribute->
            PositionAttribute(attribute).also {
                it.positionToUniquePosition=this
                it.positionToCurrentPosition=null }
        }.toMutableSet()

        limits=currentPosition.limits.map {limits-> Limits(limits,this)}.toMutableSet()
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "unique_position_id")
    open var uniquePositionId: Long? = null

    @Column(name = "position_name", length = 60, nullable = false)
    open var name: String? = null

    @OneToMany(mappedBy = "positionToUniquePosition", cascade = [CascadeType.ALL], orphanRemoval = true)
    open var attributes= mutableSetOf<PositionAttribute>()

    @OneToMany(mappedBy = "positionToUniquePosition", cascade = [CascadeType.ALL], orphanRemoval = true)
    open var limits= mutableSetOf<Limits>()

    @ManyToOne
    @JoinColumn(name = "company_id", nullable = false)
    open var company: Company?=null

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is UniquePosition) return false

        if (name != other.name) return false
        if (attributes != other.attributes) return false

        return true
    }

    override fun hashCode(): Int {
        var result = name?.hashCode() ?: 0
        result = 31 * result + attributes.hashCode()
        return result
    }


}