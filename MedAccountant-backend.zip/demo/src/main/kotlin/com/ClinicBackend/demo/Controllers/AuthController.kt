package com.ClinicBackend.demo.Controllers

import com.ClinicBackend.demo.Security.AuthRequest
import com.ClinicBackend.demo.Security.AuthResponse
import com.ClinicBackend.demo.Security.CustomUserDetailsService
import com.ClinicBackend.demo.Security.JwtProvider
import jakarta.servlet.ServletException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.authentication.AuthenticationManager
import org.springframework.security.authentication.BadCredentialsException
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.web.bind.annotation.*


@RestController
class AuthController {
    @Autowired
    lateinit private var userDetailsService: CustomUserDetailsService
    @Autowired
    lateinit private var jwtProvider: JwtProvider
    @Autowired
    lateinit private var authenticationManager: AuthenticationManager

    @PostMapping("/auth")
    fun createAuthToken(@RequestBody authRequest: AuthRequest): ResponseEntity<Any> {
        authenticationManager.authenticate(
            UsernamePasswordAuthenticationToken(
                authRequest.login,
                authRequest.password
            )
        )
        val userDetails=userDetailsService.loadUserByUsername(authRequest.login)
        val token=jwtProvider.generateToken(userDetails)
        println("token: $token")
        return ResponseEntity.ok(AuthResponse(token))
    }

    @GetMapping("/auth_check")
    fun checkAuthToken()=ResponseEntity.ok("authorized")

    @ExceptionHandler(RuntimeException::class)
    fun handleAuthExceptions(exc: RuntimeException?): ResponseEntity<*> {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED.value()).body(exc!!.message)
    }

    @ExceptionHandler(BadCredentialsException::class)
    fun handleBadCredentialsExceptions(exc:BadCredentialsException?): ResponseEntity<*> {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED.value()).body(
            if(exc!!.message!!.startsWith("User"))exc.message
            else "Incorrect password"
        )
    }
}