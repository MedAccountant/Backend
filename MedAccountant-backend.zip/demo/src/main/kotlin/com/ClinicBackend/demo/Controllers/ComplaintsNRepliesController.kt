package com.ClinicBackend.demo.Controllers

import com.ClinicBackend.demo.DTO.CRDTOs.*
import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.ManageFilesAndDB.Exceptions.SavePositionException
import com.ClinicBackend.demo.Service.ComplaintsNRepliesService
import io.swagger.v3.oas.annotations.Operation
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/{companyName}/complaints_and_replies")
class ComplaintsNRepliesController {
    @Autowired
    lateinit var utils: Utils

    @Autowired
    lateinit var complaintsNRepliesService: ComplaintsNRepliesService

    //utils

    @Operation(description = "Get list of logins from departments in area of responsibility of user")
    @GetMapping("/logins")
    fun getLoginsForComplaints(@PathVariable companyName: String
    ): ResponseEntity<List<DepartmentDTO>> {
        val departmentDTOs=utils.getUsersDepartments(companyName).map { DepartmentDTO(it) }
        return ResponseEntity.ok(departmentDTOs)
    }

    @Operation(description = "Get list of themes of complaints and replies")
    @GetMapping("/themes")
    fun getThemes(
        @PathVariable companyName: String
    ): ResponseEntity<List<ThemeDTO>> {
        val themeDTOs = complaintsNRepliesService.getThemes(utils.getUser()).map { ThemeDTO(it!!) }
        return ResponseEntity.ok(themeDTOs)
    }

    @Operation(description = "Get list of complaints of complaints and replies for theme (use _ instead ot whitespace)")
    @GetMapping("/themes/{themeName}")
    fun getCRsByTheme(
        @PathVariable companyName: String,
        @PathVariable themeName: String
    ): ResponseEntity<List<ComplaintsNRepliesDTO>> {
        val crDTOs =
            complaintsNRepliesService.getCRByTheme(utils.getUser(), themeName.replace('_',' ')).map { ComplaintsNRepliesDTO(it) }
        return ResponseEntity.ok(crDTOs)
    }

    @Operation(description = "Get complaint by id")
    @GetMapping("/{crId}")
    fun getCRById(
        @PathVariable companyName: String,
        @PathVariable crId: Long
    ): ResponseEntity<CRDetailedInfoDTO> {
        val cr=complaintsNRepliesService.getCRByIdToWatch(crId,utils.getUser())
        return ResponseEntity.ok(CRDetailedInfoDTO(cr))
    }

    @Operation(description = "Edit complaint by id (and close complaint by setting closedMarker=true)")
    @PutMapping("/{crId}")
    fun editCRById(
        @PathVariable companyName: String,
        @PathVariable crId: Long,
        @RequestBody editCnRDTO: EditCnRDTO
    ): ResponseEntity<CRDetailedInfoDTO> {
        val cr=complaintsNRepliesService.editCRById(crId,editCnRDTO, utils.getUser())
        return ResponseEntity.ok(CRDetailedInfoDTO(cr))
    }

    @Operation(description = "Reply on complaint by id with text in field 'reply' in dto")
    @PostMapping("/{crId}")
    fun replyCRById(
        @PathVariable companyName: String,
        @PathVariable crId: Long,
        @RequestBody replyDTO: ReplyDTO
    ): ResponseEntity<CRDetailedInfoDTO> {
        val cr=complaintsNRepliesService.replyOnComplaint(crId,utils.getUser(),replyDTO.reply!!)
        return ResponseEntity.ok(CRDetailedInfoDTO(cr))
    }

    @Operation(description = "Create new complaint")
    @PostMapping()
    fun createCR(
        @PathVariable companyName: String,
        @RequestBody editCnRDTO: EditCnRDTO
    ): ResponseEntity<CRDetailedInfoDTO> {
        val cr=complaintsNRepliesService.createComplaint(editCnRDTO, utils.getUser())
        return ResponseEntity.ok(CRDetailedInfoDTO(cr))
    }

    @ExceptionHandler(RuntimeException::class)
    fun handleCRExceptions(exc: RuntimeException?): ResponseEntity<*> {
        return ResponseEntity.internalServerError().body(exc!!.message)
    }
}