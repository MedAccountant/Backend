package com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork

import com.ClinicBackend.demo.Entities.ManageLoadedData.DocType
import com.ClinicBackend.demo.Entities.ManageLoadedData.LoadedData
import com.ClinicBackend.demo.Entities.ManagePositions.*
import com.ClinicBackend.demo.Entities.ManageUsers.User
import com.ClinicBackend.demo.ManageFilesAndDB.Exceptions.StorageException
import com.ClinicBackend.demo.Repos.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.io.FileInputStream
import java.time.LocalDate
import java.time.LocalDateTime

@Service
class LoadedDataDAO {

    @Autowired
    private lateinit var loadedDataRepos: LoadedDataRepos

    @Autowired
    private lateinit var departmentRepos: DepartmentRepos

    @Autowired
    private lateinit var companyRepos: CompanyRepos

    @Autowired
    private lateinit var currentPositionsService: CurrentPositionsService

    @Autowired
    private lateinit var uniquePositionsService: UniquePositionsService

    @Autowired
    private lateinit var positionDataDAO: PositionDataDAO

    fun startProcessingDependingOnDocType(sender: User, linkToFile:String, docType: DocType, companyName:String){
        val loadedData=LoadedData()
        loadedData.uploadDateTime = LocalDateTime.now()
        //println("sender: $sender")
        loadedData.documentType=docType
        loadedData.linkToFile=linkToFile
        val department=sender.getWorkingDepartments().first()
        //println("department: ${department.departmentName}")
        loadedData.department=departmentRepos.findByDepartmentNameAndCompany(
            department.departmentName!!,
            companyRepos.findByCompanyName(companyName)!!)
        //println("founded: ${loadedData.department?.departmentName}")
        loadedData.sender=sender
        when(docType){
            DocType.ActualData->processActual(loadedData)
            DocType.WriteOffData->processWriteOff(loadedData)
            DocType.AdmissionData->processAdmission(loadedData)
        }
        loadedDataRepos.save(loadedData)
    }

    fun processActual(loadedData: LoadedData){
        val fileInStream = FileInputStream(loadedData.linkToFile!!)
        val reader=fileInStream.bufferedReader()
        val possibleAttributes:List<String> = reader.readLine().split('|').map{it.trim(' ')}
        val positionRows=reader.readLines().map { it.split('|').map{it.trim(' ')} }
        val indOfCountColumn=possibleAttributes.indexOf("Количество")
        for(row in positionRows){
            val newPositionData=PositionData()
            newPositionData.name=row[0]
            newPositionData.loadedData=loadedData
            newPositionData.count=row[indOfCountColumn].toDouble().toLong()
            newPositionData.attributes=row.mapIndexed { index, value ->
                PositionAttribute().also {
                    it.attributeName=possibleAttributes[index]
                    it.value=value
                    it.positionToPositionData=newPositionData
                } }.filterIndexed {
                    index, attr -> index!=0 && index!=indOfCountColumn && attr.value!=""
            }.toMutableSet()
            //find position in current positions
            val inCurrentPositions=currentPositionsService.getEqualCurrentPositions(newPositionData, listOf(loadedData.department!!))
            //println("founded in currentPositions: ${inCurrentPositions.map { it.name }.joinToString(",")}")
            if(inCurrentPositions.isNotEmpty()){
                //get limits from most suitable current position
                val possibleCurrentLimits=inCurrentPositions.first().limits
                val newLimits= possibleCurrentLimits.map { Limits(it,newPositionData) }.toMutableSet()
                newPositionData.limits=newLimits
                newPositionData.uniqueMarker=false
                newPositionData.processedMarker=true
                newPositionData.processedBy=loadedData.sender
                //update count of position in current positions table
                inCurrentPositions.first().count=newPositionData.count
                currentPositionsService.saveCurrentPosition(inCurrentPositions.first(),
                    loadedData.department!!.company!!.companyName!!)
                //println("limits from current pos")
            }
            else{
                val equalUniquePosition=uniquePositionsService.getUniquePositionByPositionData(newPositionData)
                if(equalUniquePosition!=null){
                    //get limits from unique position
                    val newLimits= equalUniquePosition.limits.map { Limits(it,newPositionData) }.toMutableSet()
                    newPositionData.limits=newLimits
                    newPositionData.uniqueMarker=true
                    newPositionData.processedMarker=false
                    //println("limits from unique pos")
                }
                else{
                    //position is unique
                    newPositionData.uniqueMarker=true
                    newPositionData.processedMarker=false
                    //println("no limits")
                }
                //update processed marker for equal positions from previous loaded data
                val inPositionData=positionDataDAO.getEqualPositionsData(
                    newPositionData,
                    listOf(loadedData.department!!)
                )
                inPositionData.forEach {
                    it.processedMarker=true
                }
                positionDataDAO.savePositionsData(inPositionData)

                //delete position from current loaded data list of positions data
                loadedData.positions.remove(newPositionData)
            }
            println("POSITION FROM LOADED DATA =====================================")
            println(newPositionData)
            println("=====================================")
            loadedData.positions.add(newPositionData)
        }
        fileInStream.close()
    }

    fun processWriteOff(loadedData: LoadedData){
        val fileInStream = FileInputStream(loadedData.linkToFile!!)
        val reader=fileInStream.bufferedReader()
        val possibleAttributes:List<String> = reader.readLine().split('|').map{it.trim(' ')}
        val positionRows=reader.readLines().map { it.split('|').map{it.trim(' ')} }
        val indOfCountColumn=possibleAttributes.indexOf("Количество")
        for(row in positionRows){
            val newPositionData=PositionData()
            newPositionData.name=row[0]
            newPositionData.loadedData=loadedData
            newPositionData.count=row[indOfCountColumn].toDouble().toLong()
            newPositionData.attributes=row.mapIndexed { index, value ->
                PositionAttribute().also {
                    it.attributeName=possibleAttributes[index]
                    it.value=value
                    it.positionToPositionData=newPositionData
                } }.filterIndexed {
                    index, attr -> index!=0 && index!=indOfCountColumn && attr.value!=""
            }.toMutableSet()
            //find position in current positions
            val inCurrentPositions=currentPositionsService.getEqualCurrentPositions(newPositionData, listOf(loadedData.department!!))
            //println("founded in currentPositions: ${inCurrentPositions.map { it.name }.joinToString(",")}")
            if(inCurrentPositions.isNotEmpty()){
                //get limits from most suitable current position
                val possibleCurrentLimits=inCurrentPositions.first().limits
                val newLimits= possibleCurrentLimits.map { Limits(it,newPositionData) }.toMutableSet()
                newPositionData.limits=newLimits
                newPositionData.uniqueMarker=false
                newPositionData.processedMarker=true
                newPositionData.processedBy=loadedData.sender
                //update count of position in current positions table
                inCurrentPositions.first().count = inCurrentPositions.first().count!! - newPositionData.count!!
                currentPositionsService.saveCurrentPosition(inCurrentPositions.first(),
                    loadedData.department!!.company!!.companyName!!)
                //println("limits from current pos")
            }
            else throw StorageException("Write-off file should not contain positions that are not current department positions")
            println(newPositionData)
            println("=====================================")
            loadedData.positions.add(newPositionData)
        }
        fileInStream.close()
    }

    fun processAdmission(loadedData: LoadedData){
        val fileInStream = FileInputStream(loadedData.linkToFile!!)
        val reader=fileInStream.bufferedReader()
        val possibleAttributes:List<String> = reader.readLine().split('|').map{it.trim(' ')}
        val positionRows=reader.readLines().map { it.split('|').map{it.trim(' ')} }
        val indOfCountColumn=possibleAttributes.indexOf("Количество")
        for(row in positionRows){
            val newPositionData=PositionData()
            newPositionData.name=row[0]
            newPositionData.loadedData=loadedData
            newPositionData.count=row[indOfCountColumn].toDouble().toLong()
            newPositionData.attributes=row.mapIndexed { index, value ->
                PositionAttribute().also {
                    it.attributeName=possibleAttributes[index]
                    it.value=value
                    it.positionToPositionData=newPositionData
                } }.filterIndexed {
                    index, attr -> index!=0 && index!=indOfCountColumn && attr.value!=""
            }.toMutableSet()
            //find position in current positions
            val inCurrentPositions=currentPositionsService.getEqualCurrentPositions(newPositionData, listOf(loadedData.department!!))
            //println("founded in currentPositions: ${inCurrentPositions.map { it.name }.joinToString(",")}")
            if(inCurrentPositions.isNotEmpty()){
                val equalCurrentPosition=inCurrentPositions.first()
                //get limits from most suitable current position
                val possibleCurrentLimits=equalCurrentPosition.limits
                val newLimits= possibleCurrentLimits.map { Limits(it,newPositionData) }.toMutableSet()
                newPositionData.limits=newLimits
                newPositionData.uniqueMarker=false
                newPositionData.processedMarker=true
                newPositionData.processedBy=loadedData.sender
                //update count of position in current positions table
                equalCurrentPosition.count = equalCurrentPosition.count!! + newPositionData.count!!
                currentPositionsService.saveCurrentPosition(equalCurrentPosition,
                    loadedData.department!!.company!!.companyName!!)
                //println("limits from current pos")
            }
            else{
                val equalUniquePosition=uniquePositionsService.getUniquePositionByPositionData(newPositionData)
                if(equalUniquePosition!=null){
                    //get limits from unique position
                    val newLimits= equalUniquePosition.limits.map { Limits(it,newPositionData) }.toMutableSet()
                    newPositionData.limits=newLimits
                    newPositionData.uniqueMarker=true
                    newPositionData.processedMarker=false
                   // println("limits from unique pos")
                }
                else{
                    //position is unique
                    newPositionData.uniqueMarker=true
                    newPositionData.processedMarker=false
                    //println("no limits")
                }
                //update processed marker for equal previous positions
                val inPositionData=positionDataDAO.getEqualPositionsData(
                    newPositionData,
                    listOf(loadedData.department!!)
                )
                if(inPositionData.isNotEmpty()){
                    inPositionData.forEach {
                        it.processedMarker=true
                    }
                    val indOfLastActualDataPositionInPositionData=inPositionData
                        .indexOfLast{ it.loadedData!!.documentType!! == DocType.ActualData }
                    for(i in indOfLastActualDataPositionInPositionData until inPositionData.size){
                        newPositionData.count=newPositionData.count!! + inPositionData[i].count!!
                    }
                    positionDataDAO.savePositionsData(inPositionData)
                    //delete position from current loaded data list of positions data
                    loadedData.positions.remove(newPositionData)
                }

            }
            println("POSITION FROM LOADED DATA =====================================")
            println(newPositionData)
            println("=====================================")
            loadedData.positions.add(newPositionData)
        }
        fileInStream.close()
    }
}