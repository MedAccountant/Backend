package com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition

import java.time.LocalDateTime

class CurrentPositionStatDTO() {
    var statistic:List<StatPointDTO> = listOf()
    constructor(stat:List<Pair<LocalDateTime,Long>>):this(){
        statistic=stat.map { StatPointDTO(it.first,it.second) }
    }
}