package com.ClinicBackend.demo.Controllers

import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.DTO.OrderDTOs.EditorExtraInfoOrderDTO
import com.ClinicBackend.demo.DTO.OrderDTOs.EditorOrderDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition.CurrentPositionDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition.CurrentPositionStatDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition.ExtraInfoForCurrentPositionDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForPositionData.ExtraInfoForPositionDataDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForPositionData.PositionDataDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.UniquePosition.ExtraInfoForUniquePositionDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.UniquePosition.UniquePositionDTO
import com.ClinicBackend.demo.Entities.ManageUsers.Role
import com.ClinicBackend.demo.ManageFilesAndDB.Exceptions.SavePositionException
import com.ClinicBackend.demo.ManageFilesAndDB.OrdersWork.OrderService
import com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork.CurrentPositionsService
import com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork.LoadedDataService
import com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork.PositionManagementException
import com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork.UniquePositionsService
import io.swagger.v3.oas.annotations.Operation
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.security.access.prepost.PreAuthorize
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile


@RestController
@RequestMapping("/{companyName}/editor")
class EditorController {
    @Autowired
    lateinit var utils:Utils

    @Autowired
    lateinit var loadedDataService: LoadedDataService

    @Autowired
    lateinit var currentPositionsService: CurrentPositionsService

    @Autowired
    lateinit var orderService: OrderService

    @Autowired
    lateinit var uniquePositionsService: UniquePositionsService

    //utils
    @Operation(description = "Get list of departments in area of responsibility of Editor")
    @GetMapping("/departments")
    fun getDepartmentsEditor(@PathVariable companyName: String
    ): ResponseEntity<List<DepartmentDTO>> {
        val departmentDTOs=utils.getUsersDepartments(companyName).map { DepartmentDTO(it) }
        return ResponseEntity.ok(departmentDTOs)
    }


    //manage new positions

    @Operation(description = "Returns new positions for one department")
    @GetMapping("/{departmentName}/new_positions")
    fun getNewPositionsOneDep(@PathVariable companyName: String,
                        @PathVariable departmentName: String
    ): ResponseEntity<List<PositionDataDTO>> {
        val department=loadedDataService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val positionDataDTOs=loadedDataService
            .getNewPositionsOfDepartmentsList(listOf(department),companyName)
            .map { PositionDataDTO(it) }
        return ResponseEntity.ok(positionDataDTOs)
    }

    @Operation(description = "Returns data for new position from one department")
    @GetMapping("/{departmentName}/new_position_info")
    fun getExtraInfoOneDepPositionData(@PathVariable companyName: String,
                           @PathVariable departmentName: String,
                           @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<ExtraInfoForPositionDataDTO> {
        val department=loadedDataService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val extraData=loadedDataService
            .getNewPositionExtraData(positionDataId, listOf(department),companyName)
        return ResponseEntity.ok(extraData)
    }

    @Operation(description = "Returns new positions from user departments")
    @GetMapping("/new_positions")
    fun getNewPositions(@PathVariable companyName: String): ResponseEntity<List<PositionDataDTO>> {
        val departments=utils.getUsersDepartments(companyName)
        if(departments.isEmpty()) throw RuntimeException("error: working departments not found")
        val positionDataDTOs=loadedDataService
            .getNewPositionsOfDepartmentsList(departments,companyName)
            .map { PositionDataDTO(it) }
        return ResponseEntity.ok(positionDataDTOs)
    }

    @Operation(description = "Returns data for new position from departments in area of responsibility of user")
    @GetMapping("/new_position_info")
    fun getExtraInfoPositionData(@PathVariable companyName: String,
                           @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<ExtraInfoForPositionDataDTO> {
        val departments=utils.getUsersDepartments(companyName)
        if(departments.isEmpty()) throw RuntimeException("error: working departments not found")
        val extraData=loadedDataService
            .getNewPositionExtraData(positionDataId, departments,companyName)
        return ResponseEntity.ok(extraData)
    }

    @Operation(description = "Update limits and attributes to actual using ExtraInfoDTO")
    @PutMapping("/{departmentName}/new_position_info")
    fun editExtraInfoOneDepPositionData(@PathVariable companyName: String,
                           @PathVariable departmentName: String,
                           @RequestParam("newPositionId") positionDataId:Long,
                            @RequestBody newExtraInfoForPositionDataDTO: ExtraInfoForPositionDataDTO
    ): ResponseEntity<ExtraInfoForPositionDataDTO> {
        newExtraInfoForPositionDataDTO.editedBy=SecurityContextHolder.getContext().authentication.name
        val department=loadedDataService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val toReturnExtraInfoForPositionData=loadedDataService
            .updateLimitsAndAttributesPositionData(positionDataId, listOf(department),newExtraInfoForPositionDataDTO,companyName)
        return ResponseEntity.ok(toReturnExtraInfoForPositionData)
    }

    @Operation(description = "Returns data for new position from departments in area of responsibility of user")
    @PutMapping("/new_position_info")
    fun editExtraInfoPositionData(@PathVariable companyName: String,
                           @RequestParam("newPositionId") positionDataId:Long,
                      @RequestBody newExtraInfoForPositionDataDTO: ExtraInfoForPositionDataDTO
    ): ResponseEntity<ExtraInfoForPositionDataDTO> {
        newExtraInfoForPositionDataDTO.editedBy=SecurityContextHolder.getContext().authentication.name
        val departments=utils.getDepartmentsForExtraInfo(newExtraInfoForPositionDataDTO,companyName)
        if(departments.isEmpty()) throw RuntimeException("error: working departments not found")
        val toReturnExtraInfoForPositionData=loadedDataService
            .updateLimitsAndAttributesPositionData(positionDataId, departments,newExtraInfoForPositionDataDTO,companyName)
        return ResponseEntity.ok(toReturnExtraInfoForPositionData)
    }

    @Operation(description = "Command to reject position by id")
    @DeleteMapping("/{departmentName}/new_position_info")
    fun rejectOnePositionData(@PathVariable companyName: String,
                            @PathVariable departmentName: String,
                            @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<Boolean> {
        val department=loadedDataService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        loadedDataService
            .rejectPositionData(positionDataId, listOf(department),companyName)
        return ResponseEntity.ok(true)
    }

    @Operation(description = "Command to reject position by id for every department where position occurs," +
            " which are in area of responsibility of user")
    @DeleteMapping("/new_position_info")
    fun rejectAllPositionData(@PathVariable companyName: String,
                            @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<Boolean> {
        val departments=utils.getUsersDepartments(companyName)
        if(departments.isEmpty()) throw RuntimeException("error: working departments not found")
        loadedDataService
            .rejectPositionData(positionDataId, departments,companyName)
        return ResponseEntity.ok(true)
    }

    @Operation(description = "Command to save position with existing limits and attributes to department")
    @PostMapping("/{departmentName}/new_position_info")
    fun saveOnePositionData(@PathVariable companyName: String,
                @PathVariable departmentName: String,
                @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<Boolean> {
        val department=loadedDataService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        loadedDataService
            .saveToCurrentPositions(positionDataId, listOf(department),companyName)
        return ResponseEntity.ok(true)
    }

    @Operation(description = "Command to save position with existing limits and attributes to every department where position occurs," +
            " which are in area of responsibility of user")
    @PostMapping("/new_position_info")
    fun saveAllPositionData(@PathVariable companyName: String,
                @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<Boolean> {
        val departments=utils.getUsersDepartments(companyName)
        if(departments.isEmpty()) throw RuntimeException("error: working departments not found")
        loadedDataService
            .saveToCurrentPositions(positionDataId, departments,companyName)
        return ResponseEntity.ok(true)
    }

    //manage current positions===========================================================

    @Operation(description = "Returns current positions for one department")
    @GetMapping("/{departmentName}/current_positions")
    fun getCurrentPositionsOneDep(@PathVariable companyName: String,
                              @PathVariable departmentName: String
    ): ResponseEntity<List<CurrentPositionDTO>> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val currentPositionDTOs=currentPositionsService
            .getCurrentPositionsFromDepartmentsList(listOf(department)/*,companyName*/)
            .map { CurrentPositionDTO(it) }
        return ResponseEntity.ok(currentPositionDTOs)
    }

    @Operation(description = "Returns data for current position from one department")
    @GetMapping("/{departmentName}/current_position_info")
    fun getExtraInfoOneDep(@PathVariable companyName: String,
                           @PathVariable departmentName: String,
                           @RequestParam("currentPositionId") currentPositionId:Long
    ): ResponseEntity<ExtraInfoForCurrentPositionDTO>{
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val extraData=currentPositionsService
            .getCurrentPositionExtraDataOneDep(currentPositionId, department,companyName)
        return ResponseEntity.ok(extraData)
    }

    @Operation(description = "Returns data for current position from one department")
    @GetMapping("/{departmentName}/current_position_info/statistic")
    fun getStatisticOneDep(@PathVariable companyName: String,
                           @PathVariable departmentName: String,
                           @RequestParam("currentPositionId") currentPositionId:Long
    ): ResponseEntity<CurrentPositionStatDTO>{
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val statDTO=currentPositionsService
            .getCurrentPositionStatistic(currentPositionId, department,companyName)
        println(statDTO.statistic.size)
        return ResponseEntity.ok(statDTO)
    }

    @Operation(description = "Returns current positions from user's departments")
    @GetMapping("/current_positions")
    fun getCurrentPositions(@PathVariable companyName: String): ResponseEntity<List<CurrentPositionDTO>> {
        val departments=utils.getUsersDepartments(companyName)
        if(departments.isEmpty()) throw RuntimeException("error: working departments not found")
        val currentPositionDTOs=currentPositionsService
            .getCurrentPositionsFromDepartmentsList(departments/*,companyName*/)
            .map { CurrentPositionDTO(it) }
        return ResponseEntity.ok(currentPositionDTOs)
    }

    @Operation(description = "Returns data for current position from departments in area of responsibility of user")
    @GetMapping("/current_position_info")
    fun getExtraInfo(@PathVariable companyName: String,
                     @RequestParam("currentPositionId") currentPositionId:Long
    ): ResponseEntity<ExtraInfoForCurrentPositionDTO> {
        val departments=utils.getUsersDepartments(companyName)
        if(departments.isEmpty()) throw RuntimeException("error: working departments not found")
        val extraData=currentPositionsService
            .getCurrentPositionExtraDataGlobal(currentPositionId, departments,companyName)
        return ResponseEntity.ok(extraData)
    }

    @Operation(description = "Update limits and attributes to actual using ExtraInfoDTO")
    @PutMapping("/{departmentName}/current_position_info")
    fun editExtraInfoOneDep(@PathVariable companyName: String,
                            @PathVariable departmentName: String,
                            @RequestParam("currentPositionId") currentPositionId:Long,
                            @RequestBody newExtraInfoForCurrentPositionDTO: ExtraInfoForCurrentPositionDTO
    ): ResponseEntity<ExtraInfoForCurrentPositionDTO> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val toReturnExtraInfoForCurrentPosition=currentPositionsService
            .updateLimitsAndAttributesCurrentPositionOneDep(
                currentPositionId,
                department,
                newExtraInfoForCurrentPositionDTO,
                companyName)
        return ResponseEntity.ok(toReturnExtraInfoForCurrentPosition)
    }

    @Operation(description = "Save current position with existing limits and attributes to department")
    @PostMapping("/{departmentName}/current_position_info")
    fun saveOne(@PathVariable companyName: String,
                @PathVariable departmentName: String,
                @RequestParam("currentPositionId") currentPositionId: Long
    ): ResponseEntity<Boolean> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        currentPositionsService.saveChangedCurrentPositionOneDep(currentPositionId, department,companyName)
        return ResponseEntity.ok(true)
    }

    @Operation(description = "Command to save current position with new limits and attributes to every department where position occurs," +
            " which are in area of responsibility of user")
    @PostMapping("/current_position_info")
    fun saveAll(@PathVariable companyName: String,
                @RequestParam("currentPositionId") currentPositionId: Long,
                @RequestBody newExtraInfoForCurrentPositionDTO: ExtraInfoForCurrentPositionDTO
    ): ResponseEntity<ExtraInfoForCurrentPositionDTO> {
        val departments=utils.getDepartmentsForExtraInfo(newExtraInfoForCurrentPositionDTO,companyName)
        if(departments.isEmpty()) throw RuntimeException("error: working departments not found")
        val toReturnExtraInfoForCurrentPosition=currentPositionsService
            .saveChangedCurrentPositionsGlobal(
                currentPositionId,
                departments,
                newExtraInfoForCurrentPositionDTO,
                companyName)
        return ResponseEntity.ok(toReturnExtraInfoForCurrentPosition)
    }

    //orders management

    @Operation(description = "Get list of orders from department")
    @GetMapping("/{departmentName}/orders")
    fun getListOfOrdersFromDepartment(
                @PathVariable companyName: String,
                @PathVariable departmentName: String
    ): ResponseEntity<List<EditorOrderDTO>> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val orders=orderService.getOrdersFromDepartment(department).map { EditorOrderDTO(it) }
        return ResponseEntity.ok(orders)
    }

    @Operation(description = "Get extraInfoFor order from department by orderName (replace whitespaces with _)")
    @GetMapping("/{departmentName}/orders/{orderName}")
    fun getExtraInfoForOrder(
        @PathVariable companyName: String,
        @PathVariable departmentName: String,
        @PathVariable orderName: String
    ): ResponseEntity<EditorExtraInfoOrderDTO> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val order=orderService.getOrderByName(orderName.replace('_',' '),department, Role.Editor)
        val orderExtraInfo=EditorExtraInfoOrderDTO(order!!)
        return ResponseEntity.ok(orderExtraInfo)
    }

    @Operation(description = "Get order file from department by orderName (replace whitespaces with _)")
    @GetMapping("/{departmentName}/orders/{orderName}/file")
    fun downloadOrderFile(
        @PathVariable companyName: String,
        @PathVariable departmentName: String,
        @PathVariable orderName: String
    ): ResponseEntity<Any> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")

        return ResponseEntity.ok()
            .body<Any>(orderService
                .loadOrderFileByNameAsResource(
                    orderName.replace('_',' '),
                    department,
                    Role.Editor)
            )
    }

    @Operation(description = "Put description for order from department by orderName (replace whitespaces with _)")
    @PutMapping("/{departmentName}/orders/{orderName}")
    fun editOrderDescription(
        @PathVariable companyName: String,
        @PathVariable departmentName: String,
        @PathVariable orderName: String,
        @RequestBody newDescription:String
    ): ResponseEntity<EditorExtraInfoOrderDTO> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val orderExtraInfo=EditorExtraInfoOrderDTO(orderService
            .setNewDescriptionToOrder(orderName.replace('_',' '),department, utils.getUser(), newDescription))
        return ResponseEntity.ok(orderExtraInfo)
    }

    @Operation(description = "Put edited file for order from department by orderName (replace whitespaces with _)")
    @PutMapping("/{departmentName}/orders/{orderName}/file")
    fun uploadEditedOrderFile(
        @PathVariable companyName: String,
        @PathVariable departmentName: String,
        @PathVariable orderName: String,
        @RequestParam("file") file: MultipartFile
    ): ResponseEntity<Any> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        orderService.setNewOrderFile(file,orderName.replace('_',' '),department, utils.getUser())
        return ResponseEntity.ok()
            .body<Any>(orderService
                .loadOrderFileByNameAsResource(
                    orderName.replace('_',' '),
                    department,
                    Role.Editor)
            )
    }

    @Operation(description = "Verify order from department by orderName (replace whitespaces with _)")
    @PostMapping("/{departmentName}/orders/{orderName}")
    fun verifyOrder(
        @PathVariable companyName: String,
        @PathVariable departmentName: String,
        @PathVariable orderName: String
    ): ResponseEntity<Any> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null || !department.workingMarker) throw RuntimeException("error: working department not found")
        if(department !in utils.getUsersDepartments(companyName)) throw RuntimeException("You don't have access to this department")
        val order=orderService.verifyOrder(orderName.replace('_',' '),department, utils.getUser())
        val orderExtraInfo=EditorExtraInfoOrderDTO(order)
        return ResponseEntity.ok(orderExtraInfo)
    }

    //manage unique positions

    @Operation(description = "Returns unique positions for clinic")
    @GetMapping("/unique_positions")
    fun getUniquePositions(@PathVariable companyName: String): ResponseEntity<List<UniquePositionDTO>> {
        val uniquePositionDTOs=uniquePositionsService.getUniquePositions(companyName).map { UniquePositionDTO(it) }
        return ResponseEntity.ok(uniquePositionDTOs)
    }

    @Operation(description = "Returns data for unique position for clinic")
    @GetMapping("/unique_position_info")
    fun getUniquePositionExtraInfo(@PathVariable companyName: String,
                     @RequestParam("uniquePositionId") uniquePositionId:Long
    ): ResponseEntity<ExtraInfoForUniquePositionDTO> {
            val extraData=uniquePositionsService.getUniquePositionExtraData(uniquePositionId,companyName)
        return ResponseEntity.ok(extraData)
    }

    @Operation(description = "Save edited unique position with new limits and attributes to company")
    @PostMapping("/unique_position_info")
    fun saveEditedUniquePosition(@PathVariable companyName: String,
                @RequestParam("uniquePositionId") uniquePositionId: Long,
                @RequestBody newExtraInfoForUniquePositionDTO: ExtraInfoForUniquePositionDTO
    ): ResponseEntity<ExtraInfoForUniquePositionDTO> {
        val toReturnExtraInfoForUniquePosition=uniquePositionsService
            .saveChangedUniquePositionByDTO(
                uniquePositionId,
                newExtraInfoForUniquePositionDTO,
                companyName
            )
        return ResponseEntity.ok(toReturnExtraInfoForUniquePosition)
    }

    @ExceptionHandler(SavePositionException::class)
    fun handleStorageFileNotFound(exc: SavePositionException?): ResponseEntity<*> {
        return ResponseEntity.internalServerError().body(exc!!.message)
    }

    @ExceptionHandler(PositionManagementException::class)
    fun handleStorageFileNotFound(exc: PositionManagementException?): ResponseEntity<*> {
        return ResponseEntity.internalServerError().body(exc!!.message)
    }

    @ExceptionHandler(RuntimeException::class)
    fun handleEditorExceptions(exc: RuntimeException?): ResponseEntity<*> {
        return ResponseEntity.internalServerError().body(exc!!.message)
    }
}