package com.ClinicBackend.demo.ManageFilesAndDB

import com.ClinicBackend.demo.Entities.ManagePositions.PositionToBuy
import com.ClinicBackend.demo.ManageFilesAndDB.Exceptions.StorageException
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.io.UrlResource
import org.springframework.stereotype.Service
import org.springframework.util.FileSystemUtils
import org.springframework.web.multipart.MultipartFile
import java.io.*
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption
import kotlin.io.path.pathString


@Service
class FileSystemStorageService (@Autowired properties: StorageProperties) : StorageService {
    private val rootLocation: Path
    private val rootLocationWright:Path
    private val ordersLocation: Path

    init {
        if (properties.location.trim { it <= ' ' }.length == 0 ||
            properties.wright.trim { it <= ' ' }.length == 0 ||
            properties.orders.trim { it <= ' ' }.length == 0) {
            throw StorageException("File upload location can not be Empty.")
        }
        rootLocation = Paths.get(properties.location)
        rootLocationWright=Paths.get(properties.wright)
        ordersLocation = Paths.get(properties.orders)
        try {
            Files.createDirectories(rootLocation)
            Files.createDirectories(rootLocationWright)
            Files.createDirectories(ordersLocation)
        } catch (e: IOException) {
            throw StorageException("Could not initialize storage", e)
        }
    }

    fun saveXLSasCSV(source:Path, destination:Path){
        //println("xls to csv")
        /*// Load the input Excel file
        val workbook = Workbook(source.pathString)
        // Save output CSV file
        workbook.save(destination.pathString, SaveFormat.CSV)*/

        // Open and existing XLSX file
        val fileInStream = FileInputStream(source.pathString)
        val fileOutStream=FileOutputStream(destination.pathString)
        val writer=fileOutStream.bufferedWriter()
        val workBook = XSSFWorkbook(fileInStream)
        val sheet = workBook.getSheetAt(0)
        val column_count=sheet.getRow(0).lastCellNum+1
        // Loop through all the rows
        val rowIterator = sheet.iterator()
        while (rowIterator.hasNext()) {
            val row: Row = rowIterator.next()
            // Loop through all rows and add ","
            val stringBuffer = StringBuffer()
            for (cn in 0 until column_count) {
                val cell: Cell? = row.getCell(cn)
                if (stringBuffer.isNotEmpty()) {
                    stringBuffer.append("|")
                }
                stringBuffer.append(
                    if(cell!=null) when (cell.cellType) {
                        CellType.BOOLEAN -> "${cell.booleanCellValue}"
                        CellType.NUMERIC -> "${cell.numericCellValue}"
                        CellType.STRING -> cell.stringCellValue
                        else -> ("${cell.cellType}")
                    }
                else (" ")/*.also { println("blank")}*/)
            }
            writer.appendLine(stringBuffer.toString())
        }
        writer.flush()
        fileInStream.close()
        fileOutStream.close()
        workBook.close()
    }

    override fun store(file: MultipartFile?):String {
        try {
            if (file!!.isEmpty) {
                throw StorageException("Failed to store empty file.")
            }
            val destinationFile: Path = rootLocation.resolve(
                Paths.get(file.originalFilename!!)
            ).normalize().toAbsolutePath()
            if (!destinationFile.parent.equals(rootLocation.toAbsolutePath())) {
                // This is a security check
                throw StorageException(
                    "Cannot store file outside current directory."
                )
            }
            file.inputStream.use { inputStream ->
                Files.copy(
                    inputStream, destinationFile,
                    StandardCopyOption.REPLACE_EXISTING
                )
            }
            //println("destination: ${destinationFile.pathString}")
            if(destinationFile.pathString.endsWith(".xlsx"))saveXLSasCSV(destinationFile, rootLocationWright.resolve(
                    Paths.get(file.originalFilename!!.replace(".xlsx",".csv"))
                    ).normalize().toAbsolutePath())
            return rootLocationWright.resolve(Paths.get(file.originalFilename!!.replace(".xlsx",".csv"))).pathString
        } catch (e: IOException) {
            throw StorageException("Failed to store file.", e)
        }
    }

    override fun loadAll(): Set<Path?>? {
        return try {
            Files.walk(rootLocation, 1).toList()
                .filter { path: Path -> path != rootLocation }
                .map(rootLocation::relativize).toSet()
        } catch (e: IOException) {
            throw StorageException("Failed to read stored files", e)
        }
    }

    override fun loadAsResource(fileName: String): UrlResource {
        //val file=loadOrderFile(fileName)
        var foundFile:Path? = Files
            .list(ordersLocation).toList().firstOrNull{ file: Path ->
                                                    file.fileName.toString().startsWith(fileName)
                                                }
        return if (foundFile != null) {
            UrlResource(foundFile.toUri())
        } else throw StorageException("File with name $fileName not found")

    }

    override fun deleteAll() {
        FileSystemUtils.deleteRecursively(rootLocation.toFile())
        FileSystemUtils.deleteRecursively(rootLocationWright.toFile())
    }

    //for orders

    override fun loadOrderFileByURLResource(filename: String): UrlResource {
        return UrlResource(ordersLocation.resolve(filename).toUri())//!!!!!!!exceptions
    }

    fun makeXLSXFromPositionsToBuy(positionsToBuy: List<PositionToBuy>, destination:Path){
        val fileOutStream= FileOutputStream(destination.pathString)
        val workBook = XSSFWorkbook()
        val sheet = workBook.createSheet()
        val attributeNamesWithRepetitions=positionsToBuy.flatMap {positionToBuy->
            positionToBuy.currentPosition!!.attributes.map{attribute-> attribute.attributeName } }
        val listOfAttributeNames=attributeNamesWithRepetitions.toSet().toMutableList()
        listOfAttributeNames.sortedBy {uniqueAttributeName->
            attributeNamesWithRepetitions.count{it==uniqueAttributeName}
        }
        val mapOfAttributesToTheirIndex:Map<String,Int> = listOfAttributeNames.mapIndexed {ind,name-> name!! to ind }.toMap()
        positionsToBuy.sortedBy { it.countToBuy }
        listOfAttributeNames.add(0,"Количество")
        val firstRow=sheet.createRow(0)
        listOfAttributeNames.forEachIndexed {ind,name->
            firstRow.createCell(ind+1,CellType.STRING).setCellValue(name)
        }
        positionsToBuy.forEachIndexed{ ind, position->
            val currentRow=sheet.createRow(ind+1)
            currentRow.createCell(0).setCellValue(position.currentPosition!!.name)
            currentRow.createCell(1,CellType.NUMERIC).setCellValue(position.countToBuy!!.toDouble())
            position.currentPosition!!.attributes.forEach{attribute->
                currentRow.createCell(2+mapOfAttributesToTheirIndex[attribute.attributeName]!!)
                    .setCellValue(attribute.value)
            }
        }
        workBook.write(fileOutStream)
        fileOutStream.close()
        workBook.close()
    }

    fun createOrderFile(positionsToBuy: List<PositionToBuy>, fileName: String):String {
        val destinationFile: Path = ordersLocation.resolve(Paths.get(fileName)).normalize().toAbsolutePath()
        if (!destinationFile.parent.equals(ordersLocation.toAbsolutePath())) {
            // This is a security check
            throw StorageException(
                "Cannot store file outside current directory."
            )
        }
        makeXLSXFromPositionsToBuy(positionsToBuy,destinationFile)
        //println("destination: ${destinationFile.pathString}")
        return destinationFile.pathString
    }

    fun updateOrderFile(file: MultipartFile?):String {
        try {
            if (file!!.isEmpty) {
                throw StorageException("Failed to store empty file.")
            }
            val destinationFile: Path = ordersLocation.resolve(
                Paths.get(file.originalFilename!!)
            ).normalize().toAbsolutePath()
            if (!destinationFile.parent.equals(ordersLocation.toAbsolutePath())) {
                // This is a security check
                throw StorageException(
                    "Cannot store file outside current directory."
                )
            }
            file.inputStream.use { inputStream ->
                Files.copy(
                    inputStream, destinationFile,
                    StandardCopyOption.REPLACE_EXISTING
                )
            }
            return ordersLocation.resolve(Paths.get(file.originalFilename!!)).pathString
        } catch (e: IOException) {
            throw StorageException("Failed to store file.", e)
        }
    }

}