package com.ClinicBackend.demo.DTO.CRDTOs

class ThemeDTO() {
    var theme:String?=null

    constructor(theme_:String):this(){theme=theme_}
}