package com.ClinicBackend.demo.DTO.CRDTOs

import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.Entities.ComplaintsNReplies

class ComplaintsNRepliesDTO() {
    var crID:Long?=null
    var senderLogin:String?=null
    var senderNickname:String?=null
    var senderDepartments:Set<DepartmentDTO>?=null
    var closedMarker:Boolean?=null

    constructor(complaintsNReplies: ComplaintsNReplies):this(){
        crID=complaintsNReplies.crId
        senderLogin=complaintsNReplies.sender!!.login
        senderNickname=complaintsNReplies.sender!!.nickname
        senderDepartments=complaintsNReplies.senderDepartments.map { DepartmentDTO(it) }.toSet()
        closedMarker=complaintsNReplies.closedMarker
    }
}