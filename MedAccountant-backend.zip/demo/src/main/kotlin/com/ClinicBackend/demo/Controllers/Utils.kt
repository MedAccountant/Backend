package com.ClinicBackend.demo.Controllers

import com.ClinicBackend.demo.DAO.CompanyDAOImpl
import com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition.ExtraInfoForCurrentPositionDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForPositionData.ExtraInfoForPositionDataDTO
import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManageUsers.Role
import com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork.LoadedDataService
import com.ClinicBackend.demo.Service.CompanyService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.stereotype.Service

@Service
class Utils() {
    @Autowired
    lateinit private var loadedDataService: LoadedDataService

    @Autowired
    lateinit private var companyService: CompanyService

    fun getUser()=companyService.getUserByLogin(SecurityContextHolder.getContext().authentication.name)?:
        throw RuntimeException("Unknown user: ${SecurityContextHolder.getContext().authentication.name}")

    fun getUsersDepartments(companyName:String)= SecurityContextHolder.getContext().authentication.authorities
        .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
            loadedDataService.getDepartmentFromCompany(it.authority,companyName)!!
        }.filter{it.workingMarker!!}

    fun getSuppliersFromDepartment(department: Department)=department.suppliers.filter { it.workingMarker==true }

    fun getDepartmentsForExtraInfo(
        extraInfoForCurrentPositionDTO: ExtraInfoForCurrentPositionDTO,
        companyName: String):List<Department>{
        val positionUsedInDepartments=extraInfoForCurrentPositionDTO.departmentsWherePositionOccurs
            .map { loadedDataService.getDepartmentFromCompany(it.departmentName!!,companyName) }
        return SecurityContextHolder.getContext().authentication.authorities
            .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
                loadedDataService.getDepartmentFromCompany(it.authority,companyName)!!
            }.filter { it.workingMarker!! && it in positionUsedInDepartments }
    }

    fun getDepartmentsForExtraInfo(
        extraInfoForPositionDataDTO: ExtraInfoForPositionDataDTO,
        companyName: String):List<Department>{
        val positionUsedInDepartments=extraInfoForPositionDataDTO.departmentsWherePositionOccurs
            .map { loadedDataService.getDepartmentFromCompany(it.departmentName!!,companyName) }
        return SecurityContextHolder.getContext().authentication.authorities
            .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
                loadedDataService.getDepartmentFromCompany(it.authority,companyName)!!
            }.filter { it.workingMarker!! && it in positionUsedInDepartments }
    }
}