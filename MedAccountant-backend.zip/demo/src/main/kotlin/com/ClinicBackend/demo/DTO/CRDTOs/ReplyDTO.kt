package com.ClinicBackend.demo.DTO.CRDTOs

class ReplyDTO {
    var reply:String?=null
}