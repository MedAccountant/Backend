package com.ClinicBackend.demo.ManageFilesAndDB.OrdersWork

import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.Order
import com.ClinicBackend.demo.Entities.ManageUsers.Role
import com.ClinicBackend.demo.Repos.OrderRepos
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class OrderDAO () {
    @Autowired
    private lateinit var orderRepos: OrderRepos

    fun getOrdersFromDepartment(department: Department)=orderRepos.findByDepartmentEquals(department)

    fun getOrdersFromDepartmentForDP(department: Department)=orderRepos
        .findByDepartmentEqualsAndDoneOrderMarkerEqualsAndVerifiedMarkerEqualsOrDepartmentEqualsAndDoneOrderMarkerEqualsAndBadOrderMarkerEquals(
            department1=department, department2 = department)

    fun getOrderByName(name:String, department: Department, role:Role): Order?{
        println("get order by name: $name")
        val order = orderRepos.findByLinkToFileEndsWith(name)
        if(order==null || order.department!=department)throw RuntimeException("Order not found or you don't have access to one")
        when(role){
            Role.DataProducer->order.readMarkerDP=true
            Role.Editor->order.readMarkerEditor=true
            else -> throw RuntimeException("Unexpected role: $role")
        }
        orderRepos.save(order)
        return order
    }

    fun saveUpdatedOrder(order: Order){
        orderRepos.save(order)
    }

    fun createOrder(linkToOrderFile:String, department: Department){
        orderRepos.save(Order(linkToOrderFile,department))
    }
}