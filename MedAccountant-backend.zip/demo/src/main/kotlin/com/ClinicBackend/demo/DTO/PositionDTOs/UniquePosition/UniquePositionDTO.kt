package com.ClinicBackend.demo.DTO.PositionDTOs.UniquePosition

import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import com.ClinicBackend.demo.Entities.ManagePositions.UniquePosition

class UniquePositionDTO() {
    var uniquePositionId:Long?=null
    var name: String? = null
    var attributeNames:List<String> = mutableListOf<String>()

    constructor(uniquePosition: UniquePosition):this(){
        uniquePositionId=uniquePosition.uniquePositionId
        name=uniquePosition.name
        attributeNames=uniquePosition.attributes.map { it.attributeName!! }
    }

    override fun toString():String{
        return  "{\n" +
                "\"name\":$name \n" +
                "\"attributes\":[\n" +
                attributeNames.joinToString { ", " }+
                " ]\n}"
    }
}