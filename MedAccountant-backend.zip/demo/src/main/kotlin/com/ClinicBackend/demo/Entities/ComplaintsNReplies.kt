package com.ClinicBackend.demo.Entities

import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManageUsers.Role
import com.ClinicBackend.demo.Entities.ManageUsers.User
import jakarta.persistence.*
import org.hibernate.annotations.GenericGenerator

@Entity
@Table(name="complaints_and_replies")
open class ComplaintsNReplies() {
    @Id
    @GeneratedValue(generator = "cr_sequence_generator")
    @GenericGenerator(
        name = "cr_sequence_generator",
        strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
        parameters = [
            org.hibernate.annotations.Parameter(name = "sequence_name", value = "cr_sequence"),
            org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
            org.hibernate.annotations.Parameter(name = "increment_size", value = "1")]
    )
    @Column(name = "cr_id")
    open var crId:Long?=null

    @Column(name="theme",length = 100, nullable = false)
    open var theme:String?=null

    @Column(name="complaint",length = 255, nullable = false)
    open var complaint:String?=null

    @Column(name="reply",length = 255)
    open var reply:String?=null

    @Enumerated(EnumType.STRING)
    @Column(name = "recipient_role")
    open var recipientRole: Role?=null

    @ManyToMany
    @JoinTable (name="complaint_department",
        joinColumns=[JoinColumn (name="complaint_id")],
        inverseJoinColumns=[JoinColumn(name="department_id")])
    open var senderDepartments= mutableSetOf<Department>()

    @Column(name="closed_marker")
    open var closedMarker:Boolean?=null

    @ManyToOne
    @JoinColumn(name = "sender_id")
    open var sender: User?=null

    @ManyToOne
    @JoinColumn(name = "recipient_id")
    open var recipient: User?=null

}