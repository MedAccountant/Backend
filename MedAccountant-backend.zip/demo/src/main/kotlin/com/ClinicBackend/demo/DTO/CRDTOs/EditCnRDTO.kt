package com.ClinicBackend.demo.DTO.CRDTOs

import com.ClinicBackend.demo.Entities.ManageUsers.Role

class EditCnRDTO() {
    var closedMarker:Boolean?=null
    var recipientLogin:String?=null
    var recipientRole: Role?=null
    var theme:String?=null
    var complaint:String?=null
}