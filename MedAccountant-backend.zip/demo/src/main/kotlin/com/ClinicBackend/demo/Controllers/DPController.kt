package com.ClinicBackend.demo.Controllers


import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.DTO.OrderDTOs.DPExtraInfoOrderDTO
import com.ClinicBackend.demo.DTO.OrderDTOs.DPOrderDTO
import com.ClinicBackend.demo.DTO.OrderDTOs.EditorExtraInfoOrderDTO
import com.ClinicBackend.demo.DTO.OrderDTOs.EditorOrderDTO
import com.ClinicBackend.demo.DTO.SupplierDTO
import com.ClinicBackend.demo.DTO.SupplierDTOForDP
import com.ClinicBackend.demo.Entities.ManageLoadedData.DocType
import com.ClinicBackend.demo.Entities.ManageUsers.Role
import com.ClinicBackend.demo.Entities.Supplier
import com.ClinicBackend.demo.ManageFilesAndDB.Exceptions.StorageException
import com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork.LoadedDataService
import com.ClinicBackend.demo.ManageFilesAndDB.Exceptions.StorageFileNotFoundException
import com.ClinicBackend.demo.ManageFilesAndDB.OrdersWork.OrderService
import com.ClinicBackend.demo.ManageFilesAndDB.StorageService
import io.swagger.v3.oas.annotations.Operation
import jakarta.validation.constraints.Email
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile

@RestController
@RequestMapping("/{companyName}/DataProducer")
class DPController{
    @Autowired
    lateinit var utils:Utils

    @Autowired
    lateinit private var storageService: StorageService

    @Autowired
    lateinit private var loadedDataService: LoadedDataService

    @Autowired
    lateinit var orderService: OrderService

    //utils
    @Operation(description = "Get list of suppliers for department of DP")
    @GetMapping("/suppliers")
    fun getSuppliersDP(@PathVariable companyName: String
    ): ResponseEntity<List<SupplierDTOForDP>> {
        val department=utils.getUsersDepartments(companyName).first()
        val supplierDTOs=utils.getSuppliersFromDepartment(department).map { SupplierDTOForDP(it) }
        return ResponseEntity.ok(supplierDTOs)
    }

    //files management

    @Operation(description = "Upload file to company in area of responsibility of DP")
    @PostMapping("/files")
    fun handleFileUpload(
        @PathVariable companyName:String,
        @RequestParam("doc_type") docType:DocType,
        @RequestParam("file") file: MultipartFile
    ):ResponseEntity<String> {
        loadedDataService.processFile(
            utils.getUser(),
            storageService.store(file),
            docType,
            companyName)
        return ResponseEntity.ok("loaded")
    }

    //orders management

    @Operation(description = "Get list of orders from department")
    @GetMapping("/orders")
    fun getListOfOrdersForDP(
        @PathVariable companyName: String
    ): ResponseEntity<List<DPOrderDTO>> {
        val department=utils.getUsersDepartments(companyName).first()
        val orders=orderService.getOrdersForDP(department).map { DPOrderDTO(it) }
        return ResponseEntity.ok(orders)
    }

    @Operation(description = "Get extraInfoFor order for DP by orderName (replace whitespaces with _)")
    @GetMapping("/orders/{orderName}")
    fun getExtraInfoForOrder(
        @PathVariable companyName: String,
        @PathVariable orderName: String
    ): ResponseEntity<DPExtraInfoOrderDTO> {
        val department=utils.getUsersDepartments(companyName).first()
        val order=orderService.getOrderByName(orderName.replace('_',' '),department, Role.DataProducer)
        val orderExtraInfo= DPExtraInfoOrderDTO(order!!)
        return ResponseEntity.ok(orderExtraInfo)
    }

    @Operation(description = "Get order file for DP by orderName (replace whitespaces with _)")
    @GetMapping("/orders/{orderName}/file")
    fun downloadOrderFileDP(
        @PathVariable companyName: String,
        @PathVariable orderName: String
    ): ResponseEntity<Any> {
        val department=utils.getUsersDepartments(companyName).first()

        /*val contentType = "application/octet-stream"
        val headerValue = ("attachment; filename=\"" + order).toString() + "\""*/

        return ResponseEntity.ok()
            .body<Any>(orderService
                .loadOrderFileByNameAsResource(
                    orderName.replace('_',' '),
                    department,
                    Role.DataProducer)
            )
    }

    @Operation(description = "Complaint about order by orderName (replace whitespaces with _)")
    @PutMapping("/orders/{orderName}")
    fun complaintAboutOrder(
        @PathVariable companyName: String,
        @PathVariable orderName: String,
        @RequestBody complaintDescription:String
    ): ResponseEntity<Any> {
        orderService.challengeOrder(complaintDescription,orderName.replace('_',' '),utils.getUser())

        /*val contentType = "application/octet-stream"
        val headerValue = ("attachment; filename=\"" + order).toString() + "\""*/

        return ResponseEntity.ok("complained")
    }

    @Operation(description = "Send order by orderName (replace whitespaces with _) to supplier")
    @PostMapping("/orders/{orderName}")
    fun sendOrder(
        @PathVariable companyName: String,
        @PathVariable orderName: String,
        @RequestParam("sendToEmail") sendToEmail:String
    ): ResponseEntity<Any> {
        val sender=utils.getUser()
        orderService.sendOrder(orderName.replace('_',' '), sendToEmail,sender)
        return ResponseEntity.ok("sent")
    }

    @ExceptionHandler(StorageFileNotFoundException::class)
    fun handleStorageFileNotFound(exc: StorageFileNotFoundException?): ResponseEntity<*> {
        return ResponseEntity.internalServerError().body(exc!!.message)
    }

    @ExceptionHandler(StorageException::class)
    fun handleStorageFileNotFound(exc: StorageException?): ResponseEntity<*> {
        return ResponseEntity.internalServerError().body(exc!!.message)
    }

    @ExceptionHandler(RuntimeException::class)
    fun handleDPExceptions(exc: RuntimeException?): ResponseEntity<*> {
        return ResponseEntity.internalServerError().body(exc!!.message)
    }
}