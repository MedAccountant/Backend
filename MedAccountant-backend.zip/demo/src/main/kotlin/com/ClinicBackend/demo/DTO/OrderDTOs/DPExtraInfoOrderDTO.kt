package com.ClinicBackend.demo.DTO.OrderDTOs

import com.ClinicBackend.demo.Entities.Order

class DPExtraInfoOrderDTO() {
    var description:String?=null
    var complaintDescription:String?=null

    constructor(order: Order):this(){
        description=order.description
        complaintDescription=order.complaintDescription
    }

    override fun toString(): String {
        return "DPExtraInfoOrderDTO(description=$description, complaintDescription=$complaintDescription)"
    }


}