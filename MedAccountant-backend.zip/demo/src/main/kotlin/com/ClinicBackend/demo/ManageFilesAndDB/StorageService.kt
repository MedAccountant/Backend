package com.ClinicBackend.demo.ManageFilesAndDB

import org.springframework.boot.autoconfigure.web.ServerProperties
import org.springframework.core.io.UrlResource
import org.springframework.web.multipart.MultipartFile
import java.nio.file.Path


interface StorageService {

    //fun init()
    fun store(file: MultipartFile?):String
    fun loadAll(): Set<Path?>?
    fun loadOrderFileByURLResource(filename: String): UrlResource
    //fun loadAsResource(filename: String?): Resource?
    fun deleteAll()
    fun loadAsResource(fileName: String): UrlResource
}