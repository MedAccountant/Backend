package com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork

import com.ClinicBackend.demo.DAO.CompanyDAOImpl
import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.AttributeDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForPositionData.ExtraInfoForPositionDataDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.LimitsDTO
import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManageLoadedData.DocType
import com.ClinicBackend.demo.Entities.ManagePositions.*
import com.ClinicBackend.demo.Entities.ManageUsers.User
import com.ClinicBackend.demo.ManageFilesAndDB.Exceptions.SavePositionException
import com.ClinicBackend.demo.Repos.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.stereotype.Service
import java.time.LocalDate
import java.time.temporal.ChronoUnit

@Service
class LoadedDataService {

    @Autowired
    private lateinit var currentPositionsService: CurrentPositionsService

    @Autowired
    private lateinit var companyDAOImpl: CompanyDAOImpl

    @Autowired
    private lateinit var loadedDataDAO: LoadedDataDAO

    @Autowired
    private lateinit var positionDataDAO: PositionDataDAO

    @Autowired
    private lateinit var userRepos: UserRepos

    fun processFile(sender: User, linkToFile:String, docType: DocType, companyName:String){
        loadedDataDAO.startProcessingDependingOnDocType(sender, linkToFile,docType,companyName)
    }

    fun getNewPositionsOfDepartmentsList(departments: List<Department>,
                                         companyName: String):List<PositionData>{
        return positionDataDAO.getNewPositionsOfDepartmentsList(departments.toSet()).distinct()
    }

    fun getNewPositionExtraData(positionDataId:Long, departments: List<Department>, companyName: String)
    : ExtraInfoForPositionDataDTO {
        val requiredPositionData=/*positionDataDTO.makePositionDataFromDTO()*/
            positionDataDAO.getPositionDataById(positionDataId)
        val equalPositions=positionDataDAO.getEqualPositionsData(requiredPositionData,departments)
        println("Equal positions from extra data: ")
        equalPositions.forEach { println(it) }
        val newExtraInfoForPositionDataDTO= ExtraInfoForPositionDataDTO()
        val limitDTOs=equalPositions.flatMap {
            position-> position.limits.map { limit->
                LimitsDTO(limit).also { it.department=DepartmentDTO(position.loadedData!!.department!!) }
            }
        }.distinct()
        newExtraInfoForPositionDataDTO.limits=limitDTOs
        newExtraInfoForPositionDataDTO.attributes=requiredPositionData.attributes.map { AttributeDTO(it) }
        newExtraInfoForPositionDataDTO.departmentsWherePositionOccurs=equalPositions
            .map { DepartmentDTO(it.loadedData!!.department!!) }.distinct()
        return newExtraInfoForPositionDataDTO
    }

    fun updateLimitsAndAttributesPositionData(positionDataId:Long,
                                              departments: List<Department>,
                                              newExtraInfoForPositionDataDTO: ExtraInfoForPositionDataDTO,
                                              companyName: String): ExtraInfoForPositionDataDTO {
        println("ExtraInfo:\n $newExtraInfoForPositionDataDTO")
        val requiredPositionData=/*positionDataDTO.makePositionDataFromDTO()*/
            positionDataDAO.getPositionDataById(positionDataId)
        val equalPositions=positionDataDAO.getEqualPositionsData(requiredPositionData,departments)
        println("Equal positions: ")
        equalPositions.forEach { println(it) }
        for(department in departments){
            val limitsForDepartment=newExtraInfoForPositionDataDTO.limits
                .filter { getDepartmentFromCompany(it.department!!.departmentName!!,companyName)==department }
                .map { it.makeLimitsFromDTO() }
            val positionDataFromDepartment=equalPositions.find { it.loadedData!!.department==department }!!
            limitsForDepartment.forEach{it.positionToPositionData=positionDataFromDepartment}
            //positionDataFromDepartment.limits=limitsForDepartment.toMutableSet()
            positionDataFromDepartment.limits.clear()
            positionDataFromDepartment.limits.addAll(limitsForDepartment)
        }
        if(requiredPositionData.attributes !=
            newExtraInfoForPositionDataDTO.attributes.map { it.makeAttributeFromDTO() }.toSet()){
            equalPositions.forEach { position->
                position.attributes.clear()
                position.attributes.addAll(newExtraInfoForPositionDataDTO.attributes
                    .map { attribute->
                        attribute.makeAttributeFromDTO().also { it.positionToPositionData = position} })
                /*position.attributes=newExtraInfoForPositionDataDTO.attributes
                    .map { attribute->
                        attribute.makeAttributeFromDTO().also { it.positionToPositionData = position} }.toMutableSet()*/ }
        }
        if(departments.size==1)equalPositions.first().editedBy=userRepos.findByLogin(newExtraInfoForPositionDataDTO.editedBy!!)
//        println("equals: ======================")
//        equalPositions.forEach { println(it) }
        positionDataDAO.savePositionsData(equalPositions)
        return getNewPositionExtraData(positionDataId,departments,companyName)
    }

    fun rejectPositionData(positionDataId:Long,
                            departments: List<Department>,
                            companyName: String):Boolean{
        val requiredPositionData=positionDataDAO.getPositionDataById(positionDataId)
        val equalPositions=positionDataDAO.getEqualPositionsData(requiredPositionData,departments)
        equalPositions.forEach {
            it.processedMarker=true
            it.processedBy=userRepos.findByLogin(SecurityContextHolder.getContext().authentication.name)
            it.rejectedMarker=true
        }
        //reject all previous positions data
        positionDataDAO.getProcessedEqualPositionsData(requiredPositionData,departments).forEach {
            it.rejectedMarker=true
        }
        positionDataDAO.savePositionsData(equalPositions)
        return true
    }

    fun saveToCurrentPositions(positionDataId:Long,
                               departments: List<Department>,
                               companyName: String):Boolean{
        val requiredPositionData=positionDataDAO.getPositionDataById(positionDataId)
        println("required position: \n ${requiredPositionData}")
        val equalPositions=positionDataDAO.getEqualPositionsData(requiredPositionData,departments)
        println("equal positions: ")
        equalPositions.forEach { println(it) }
        println("=======================================")
        for(position in equalPositions){
            val limits=position.limits.sortedBy { it.startDate }
            if(limits.isEmpty()) throw SavePositionException("there is no limits")
            checkLimits(limits)
        }

        currentPositionsService.saveAllCurrentPositions(equalPositions.map { CurrentPosition(it,it.loadedData!!.department!!) })
        equalPositions.forEach {
            it.processedMarker=true
            it.processedBy=userRepos.findByLogin(SecurityContextHolder.getContext().authentication.name)
        }
        println("equal positions processed")
        positionDataDAO.savePositionsData(equalPositions)
        println("saved")
        return true
    }

    fun checkLimits(limits:List<Limits>){
        val now = LocalDate.now()
        limits.firstOrNull { it.startDate!!<=now && now<=it.endDate!!}?:
            throw SavePositionException("The position must have limits for the current date")
        var daysCount:Int= ChronoUnit.DAYS.between(limits[0].startDate,limits[0].endDate).toInt()
        for(i in 1 until limits.size){
            if(limits[i-1].endDate!! !=  limits[i].startDate!!.minusDays(1))
                throw SavePositionException("There are limits with intersections or intervals between dates")
            daysCount+= ChronoUnit.DAYS.between(limits[i].startDate,limits[i].endDate).toInt()
        }
        if(daysCount<365)
            throw SavePositionException("Initialize limits for 365 days")
    }

    fun getDepartmentFromCompany(departmentName:String,companyName: String)=
        companyDAOImpl.getDepartmentByNameAndCompany(departmentName,companyName)
}