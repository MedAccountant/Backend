package com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition

import java.time.LocalDateTime

class StatPointDTO(var dateTime:LocalDateTime,
                   var count:Long)