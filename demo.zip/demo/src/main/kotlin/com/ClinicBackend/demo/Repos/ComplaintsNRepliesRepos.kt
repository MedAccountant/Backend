package com.ClinicBackend.demo.Repos

import com.ClinicBackend.demo.Entities.ComplaintsNReplies
import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManageUsers.Role
import com.ClinicBackend.demo.Entities.ManageUsers.User
import com.ClinicBackend.demo.Entities.Order
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository

@Repository
interface ComplaintsNRepliesRepos: JpaRepository<ComplaintsNReplies, Long> {

    @Query("SELECT cr FROM ComplaintsNReplies cr WHERE " +
            "cr.recipientRole = :recRole AND " +
            "EXISTS (SELECT 1 FROM Department dep WHERE dep IN :departments AND dep MEMBER OF cr.senderDepartments) OR " +
            "cr.sender = :sender OR " +
            "cr.recipient = :recipient")
    fun findCRsForUser(
        @Param("departments") departments: Set<Department>,
        @Param("recRole") recRole: Role,
        @Param("sender") sender: User,
        @Param("recipient") recipient: User
    ): List<ComplaintsNReplies>

    @Query("SELECT cr FROM ComplaintsNReplies cr WHERE " +
            "cr.crId = :crId AND " +
            "(cr.recipientRole = :recRole AND " +
            "EXISTS (SELECT 1 FROM Department dep WHERE dep IN :departments AND dep MEMBER OF cr.senderDepartments) OR " +
            "cr.sender = :sender OR " +
            "cr.recipient = :recipient)")
    fun findCRByIdForUser(
        @Param("crId") crId: Long,
        @Param("departments") departments: Set<Department>,
        @Param("recRole") recRole: Role,
        @Param("sender") sender: User,
        @Param("recipient") recipient: User
    ): ComplaintsNReplies?
}