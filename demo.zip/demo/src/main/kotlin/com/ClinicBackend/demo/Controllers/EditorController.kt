package com.ClinicBackend.demo.Controllers

import com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition.CurrentPositionDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition.ExtraInfoForCurrentPositionDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForPositionData.ExtraInfoForPositionDataDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForPositionData.PositionDataDTO
import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import com.ClinicBackend.demo.ManageFiles.DBWork.CurrentPositionsService
import com.ClinicBackend.demo.ManageFiles.DBWork.LoadedDataService
import com.ClinicBackend.demo.Service.CompanyService
import io.swagger.v3.oas.annotations.Operation
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/{companyName}/editor")
class EditorController {
    @Autowired
    lateinit var loadedDataService: LoadedDataService

    @Autowired
    lateinit var currentPositionsService: CurrentPositionsService

    //manage new positions

    @Operation(description = "Returns new positions for one department")
    @GetMapping("/{departmentName}/new_positions")
    fun getNewPositionsOneDep(@PathVariable companyName: String,
                        @PathVariable departmentName: String
                        /*@RequestBody departmentDTOs:List<DepartmentDTO>*/
    ): ResponseEntity<List<PositionDataDTO>> {
        val department=loadedDataService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null) println("error: department not found")
        val positionDataDTOs=loadedDataService
            .getNewPositionsOfDepartmentsList(listOf(department!!),companyName)
            .map { PositionDataDTO(it) }
        return ResponseEntity.ok(positionDataDTOs)
    }

    @Operation(description = "Returns data for new position from one department")
    @GetMapping("/{departmentName}/new_position_info")
    fun getExtraInfoOneDepPositionData(@PathVariable companyName: String,
                           @PathVariable departmentName: String,
                           @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<ExtraInfoForPositionDataDTO> {
        val department=loadedDataService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null) println("error: department not found")
        val extraData=loadedDataService
            .getNewPositionExtraData(positionDataId, listOf(department!!),companyName)
        return ResponseEntity.ok(extraData)
    }

    @Operation(description = "Returns new positions from user departments")
    @GetMapping("/new_positions")
    fun getNewPositions(@PathVariable companyName: String): ResponseEntity<List<PositionDataDTO>> {
        val departments=SecurityContextHolder.getContext().authentication.authorities
            .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
                loadedDataService.getDepartmentFromCompany(it.authority,companyName)!!
            }
        if(departments.isEmpty()) println("error: departments not found")
        val positionDataDTOs=loadedDataService
            .getNewPositionsOfDepartmentsList(departments,companyName)
            .map { PositionDataDTO(it) }
        return ResponseEntity.ok(positionDataDTOs)
    }

    @Operation(description = "Returns data for new position from departments in area of responsibility of user")
    @GetMapping("/new_position_info")
    fun getExtraInfoPositionData(@PathVariable companyName: String,
                           @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<ExtraInfoForPositionDataDTO> {
        val departments=SecurityContextHolder.getContext().authentication.authorities
            .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
                loadedDataService.getDepartmentFromCompany(it.authority,companyName)!!
            }
        departments.forEach { println(it) }
        if(departments.isEmpty()) println("error: departments not found")
        val extraData=loadedDataService
            .getNewPositionExtraData(positionDataId, departments,companyName)
        return ResponseEntity.ok(extraData)
    }

    @Operation(description = "Update limits and attributes to actual using ExtraInfoDTO")
    @PutMapping("/{departmentName}/new_position_info")
    fun editExtraInfoOneDepPositionData(@PathVariable companyName: String,
                           @PathVariable departmentName: String,
                           @RequestParam("newPositionId") positionDataId:Long,
                            @RequestBody newExtraInfoForPositionDataDTO: ExtraInfoForPositionDataDTO
    ): ResponseEntity<ExtraInfoForPositionDataDTO> {
        newExtraInfoForPositionDataDTO.editedBy=SecurityContextHolder.getContext().authentication.name
        val department=loadedDataService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null) println("error: department not found")
        val toReturnExtraInfoForPositionData=loadedDataService
            .updateLimitsAndAttributesPositionData(positionDataId, listOf(department!!),newExtraInfoForPositionDataDTO,companyName)
        return ResponseEntity.ok(toReturnExtraInfoForPositionData)
    }

    @Operation(description = "Returns data for new position from departments in area of responsibility of user")
    @PutMapping("/new_position_info")
    fun editExtraInfoPositionData(@PathVariable companyName: String,
                           @RequestParam("newPositionId") positionDataId:Long,
                      @RequestBody newExtraInfoForPositionDataDTO: ExtraInfoForPositionDataDTO
    ): ResponseEntity<ExtraInfoForPositionDataDTO> {
        newExtraInfoForPositionDataDTO.editedBy=SecurityContextHolder.getContext().authentication.name
        val positionUsedInDepartments=newExtraInfoForPositionDataDTO.departmentsWherePositionOccurs
            .map { loadedDataService.getDepartmentFromCompany(it.departmentName!!,companyName) }
        val departments=SecurityContextHolder.getContext().authentication.authorities
            .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
                loadedDataService.getDepartmentFromCompany(it.authority,companyName)!!
            }.filter { it in positionUsedInDepartments }
        departments.forEach { println(it) }
        if(departments.isEmpty()) println("error: departments not found")
        val toReturnExtraInfoForPositionData=loadedDataService
            .updateLimitsAndAttributesPositionData(positionDataId, departments,newExtraInfoForPositionDataDTO,companyName)
        return ResponseEntity.ok(toReturnExtraInfoForPositionData)
    }

    @Operation(description = "Command to save position with existing limits and attributes to department")
    @PostMapping("/{departmentName}/new_position_info")
    fun saveOnePositionData(@PathVariable companyName: String,
                @PathVariable departmentName: String,
                @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<Boolean> {
        val department=loadedDataService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null) println("error: department not found")
        loadedDataService
            .saveToCurrentPositions(positionDataId, listOf(department!!),companyName)
        return ResponseEntity.ok(true)
    }

    @Operation(description = "Command to save position with existing limits and attributes to every department where position occurs," +
            " which are in area of responsibility of ")
    @PostMapping("/new_position_info")
    fun saveAllPositionData(@PathVariable companyName: String,
                @RequestParam("newPositionId") positionDataId:Long
    ): ResponseEntity<Boolean> {
        val departments=SecurityContextHolder.getContext().authentication.authorities
            .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
                loadedDataService.getDepartmentFromCompany(it.authority,companyName)!!
            }
        if(departments.isEmpty()) println("error: departments not found")
        loadedDataService
            .saveToCurrentPositions(positionDataId, departments,companyName)
        return ResponseEntity.ok(true)
    }

    //manage current positions===========================================================

    @Operation(description = "Returns current positions for one department")
    @GetMapping("/{departmentName}/current_positions")
    fun getCurrentPositionsOneDep(@PathVariable companyName: String,
                              @PathVariable departmentName: String
    ): ResponseEntity<List<CurrentPositionDTO>> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null) println("error: department not found")
        val currentPositionDTOs=currentPositionsService
            .getCurrentPositionsFromDepartmentsList(listOf(department!!)/*,companyName*/)
            .map { CurrentPositionDTO(it) }
        return ResponseEntity.ok(currentPositionDTOs)
    }

    @Operation(description = "Returns data for current position from one department")
    @GetMapping("/{departmentName}/current_position_info")
    fun getExtraInfoOneDep(@PathVariable companyName: String,
                           @PathVariable departmentName: String,
                           @RequestParam("currentPositionId") currentPositionId:Long
    ): ResponseEntity<ExtraInfoForCurrentPositionDTO>{
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null) println("error: department not found")
        val extraData=currentPositionsService
            .getCurrentPositionExtraDataOneDep(currentPositionId, department!!,companyName)
        return ResponseEntity.ok(extraData)
    }

    @Operation(description = "Returns current positions from user's departments")
    @GetMapping("/current_positions")
    fun getCurrentPositions(@PathVariable companyName: String): ResponseEntity<List<CurrentPositionDTO>> {
        val departments=SecurityContextHolder.getContext().authentication.authorities
            .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
                currentPositionsService.getDepartmentFromCompany(it.authority,companyName)!!
            }
        if(departments.isEmpty()) println("error: departments not found")
        val currentPositionDTOs=currentPositionsService
            .getCurrentPositionsFromDepartmentsList(departments/*,companyName*/)
            .map { CurrentPositionDTO(it) }
        return ResponseEntity.ok(currentPositionDTOs)
    }

    @Operation(description = "Returns data for current position from departments in area of responsibility of user")
    @GetMapping("/current_position_info")
    fun getExtraInfo(@PathVariable companyName: String,
                     @RequestParam("currentPositionId") currentPositionId:Long
    ): ResponseEntity<ExtraInfoForCurrentPositionDTO> {
        val departments=SecurityContextHolder.getContext().authentication.authorities
            .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
                currentPositionsService.getDepartmentFromCompany(it.authority,companyName)!!
            }
        if(departments.isEmpty()) println("error: departments not found")
        val extraData=currentPositionsService
            .getCurrentPositionExtraDataGlobal(currentPositionId, departments,companyName)
        return ResponseEntity.ok(extraData)
    }

    @Operation(description = "Update limits and attributes to actual using ExtraInfoDTO")
    @PutMapping("/{departmentName}/current_position_info")
    fun editExtraInfoOneDep(@PathVariable companyName: String,
                            @PathVariable departmentName: String,
                            @RequestParam("currentPositionId") currentPositionId:Long,
                            @RequestBody newExtraInfoForCurrentPositionDTO: ExtraInfoForCurrentPositionDTO
    ): ResponseEntity<ExtraInfoForCurrentPositionDTO> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null) println("error: department not found")
        val toReturnExtraInfoForCurrentPosition=currentPositionsService
            .updateLimitsAndAttributesCurrentPositionOneDep(
                currentPositionId,
                department!!,
                newExtraInfoForCurrentPositionDTO,
                companyName)
        return ResponseEntity.ok(toReturnExtraInfoForCurrentPosition)
    }

    @Operation(description = "Save current position with existing limits and attributes to department")
    @PostMapping("/{departmentName}/current_position_info")
    fun saveOne(@PathVariable companyName: String,
                @PathVariable departmentName: String,
                @RequestParam("currentPositionId") currentPositionId: Long
    ): ResponseEntity<Boolean> {
        val department=currentPositionsService.getDepartmentFromCompany(departmentName,companyName)
        if(department==null) println("error: department not found")
        currentPositionsService.saveChangedCurrentPositionOneDep(currentPositionId, department!!,companyName)
        return ResponseEntity.ok(true)
    }

    @Operation(description = "Command to save current position with new limits and attributes to every department where position occurs," +
            " which are in area of responsibility of user")
    @PostMapping("/current_position_info")
    fun saveAll(@PathVariable companyName: String,
                @RequestParam("newPositionId") currentPositionId: Long,
                @RequestBody newExtraInfoForCurrentPositionDTO: ExtraInfoForCurrentPositionDTO
    ): ResponseEntity<ExtraInfoForCurrentPositionDTO> {
        val departments=SecurityContextHolder.getContext().authentication.authorities
            .take(SecurityContextHolder.getContext().authentication.authorities.size-1).map {
                loadedDataService.getDepartmentFromCompany(it.authority,companyName)!!
            }
        if(departments.isEmpty()) println("error: departments not found")
        val toReturnExtraInfoForCurrentPosition=currentPositionsService
            .saveChangedCurrentPositionsGlobal(
                currentPositionId,
                departments,
                newExtraInfoForCurrentPositionDTO,
                companyName)
        return ResponseEntity.ok(toReturnExtraInfoForCurrentPosition)
    }

}