package com.ClinicBackend.demo.DTO.OrderDTOs

import com.ClinicBackend.demo.Entities.Order

class DPOrderDTO() {
    var orderName: String? = null
    var senderLogin:String?=null
    var readMarker=false

    constructor(order: Order):this(){
        orderName=order.linkToFile!!.substringAfterLast("\\").substringBeforeLast(".xlsx")
        senderLogin=order.sender?.login
        readMarker=order.readMarkerDP
    }
}