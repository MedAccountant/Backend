package com.ClinicBackend.demo.Security

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.web.servlet.FilterRegistrationBean
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.core.Ordered
import org.springframework.http.HttpStatus
import org.springframework.security.authentication.dao.DaoAuthenticationProvider
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer
import org.springframework.security.config.http.SessionCreationPolicy
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.security.web.SecurityFilterChain
import org.springframework.security.web.authentication.HttpStatusEntryPoint
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter
import org.springframework.web.cors.CorsConfiguration
import org.springframework.web.cors.CorsConfigurationSource
import org.springframework.web.cors.UrlBasedCorsConfigurationSource
import org.springframework.web.filter.CorsFilter


@Configuration
@EnableWebSecurity
class WebSecurityConfig {
    @Autowired
    lateinit private var userService:UserDetailsService

    @Autowired
    lateinit private var jwtFilter: JwtFilter

    @Bean
    fun passwordEncoder()=BCryptPasswordEncoder()

    @Bean
    fun authenticationManager(authenticationConfiguration:AuthenticationConfiguration)=
        authenticationConfiguration.authenticationManager

    @Bean
    fun daoAuthenticationProvider()=DaoAuthenticationProvider(passwordEncoder()).also{it.setUserDetailsService(userService)}

    @Bean
    @Throws(Exception::class)
    fun filterChain(http: HttpSecurity): SecurityFilterChain {
        http
            .csrf{it.disable()}
            //.cors { it.disable() }
            .authorizeHttpRequests{
                it//.requestMatchers("/{companyName}/admin/**").hasAuthority("Admin")

                    //.requestMatchers("/{companyName}/admin").hasAuthority()
                .anyRequest().permitAll()
            }
            .sessionManagement {
                it.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            }
            .exceptionHandling{it.authenticationEntryPoint(HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED))}
            .addFilterBefore(jwtFilter,UsernamePasswordAuthenticationFilter::class.java)
            .logout { logout: LogoutConfigurer<HttpSecurity?> -> logout.permitAll() }
        return http.build()
    }

    @Bean
    fun corsConfigurationSource(): CorsConfigurationSource {
        val configuration = CorsConfiguration()
        configuration.allowedOrigins = listOf("*")
        configuration.allowedMethods = listOf("GET", "POST", "PUT", "DELETE")
        val source = UrlBasedCorsConfigurationSource()
        source.registerCorsConfiguration("/**", configuration)
        return source
    }

    @Bean
    fun corsFilterRegistrationBean(corsConfigurationSource: CorsConfigurationSource): FilterRegistrationBean<CorsFilter> {
        val corsFilter = CorsFilter(corsConfigurationSource)
        val filterRegistrationBean: FilterRegistrationBean<CorsFilter> = FilterRegistrationBean()
        filterRegistrationBean.order = Ordered.HIGHEST_PRECEDENCE
        filterRegistrationBean.filter=corsFilter
        return filterRegistrationBean
    }

}