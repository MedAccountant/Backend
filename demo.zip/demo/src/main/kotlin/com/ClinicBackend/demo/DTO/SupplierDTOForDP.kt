package com.ClinicBackend.demo.DTO

import com.ClinicBackend.demo.Entities.Supplier

class SupplierDTOForDP() {
    var email: String? = null
    var name: String? = null

    constructor(supplier: Supplier):this(){
        email=supplier.email
        name=supplier.name
    }
}