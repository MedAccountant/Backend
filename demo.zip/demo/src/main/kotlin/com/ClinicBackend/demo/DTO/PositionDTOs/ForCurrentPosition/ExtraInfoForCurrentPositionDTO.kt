package com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition

import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.AttributeDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.LimitsDTO
import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import com.ClinicBackend.demo.Entities.ManagePositions.PositionData

class ExtraInfoForCurrentPositionDTO() {
    var attributes:List<AttributeDTO> = mutableListOf<AttributeDTO>()
    var limits:List<LimitsDTO> = mutableListOf<LimitsDTO>()
    var departmentsWherePositionOccurs:List<DepartmentDTO> = mutableListOf<DepartmentDTO>()
    var changingMarker:Boolean=false

    constructor(currentPosition: CurrentPosition):this(){
        attributes=currentPosition.attributes.map { AttributeDTO(it) }
        limits=currentPosition.limits.map { LimitsDTO(it) }
    }

    override fun toString():String{
        return  "{\n" +
                "\"attributes\":[\n" +
                attributes.joinToString { ",\n " }+
                "],\n"+
                "\"limits\":[\n" +
                limits.joinToString { ",\n " }+
                "]\n}"
    }
}