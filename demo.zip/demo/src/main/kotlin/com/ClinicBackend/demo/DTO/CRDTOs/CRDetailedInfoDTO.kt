package com.ClinicBackend.demo.DTO.CRDTOs

import com.ClinicBackend.demo.Entities.ComplaintsNReplies

class CRDetailedInfoDTO() {
    var complaint:String?=null
    var reply:String?=null
    var replierLogin:String?=null
    var replierNickname:String?=null

    constructor(complaintsNReplies: ComplaintsNReplies):this(){
        complaint=complaintsNReplies.complaint
        reply=complaintsNReplies.reply
        replierLogin=complaintsNReplies.recipient?.login
        replierNickname=complaintsNReplies.recipient?.nickname
    }
}