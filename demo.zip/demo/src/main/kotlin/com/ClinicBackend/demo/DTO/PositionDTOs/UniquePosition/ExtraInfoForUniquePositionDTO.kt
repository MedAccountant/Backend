package com.ClinicBackend.demo.DTO.PositionDTOs.UniquePosition

import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.AttributeDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.LimitsDTO
import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import com.ClinicBackend.demo.Entities.ManagePositions.UniquePosition

class ExtraInfoForUniquePositionDTO() {
    var attributes:List<AttributeDTO> = mutableListOf<AttributeDTO>()
    var limits:List<LimitsDTOForUniquePosition> = mutableListOf<LimitsDTOForUniquePosition>()

    constructor(uniquePosition: UniquePosition):this(){
        attributes=uniquePosition.attributes.map { AttributeDTO(it) }
        limits=uniquePosition.limits.map { LimitsDTOForUniquePosition(it) }
    }

    override fun toString():String{
        return  "{\n" +
                "\"attributes\":[\n" +
                attributes.joinToString { ",\n " }+
                "],\n"+
                "\"limits\":[\n" +
                limits.joinToString { ",\n " }+
                "]\n}"
    }
}