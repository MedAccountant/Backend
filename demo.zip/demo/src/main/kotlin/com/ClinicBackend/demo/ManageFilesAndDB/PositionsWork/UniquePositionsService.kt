package com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork

import com.ClinicBackend.demo.DAO.CompanyDAOImpl
import com.ClinicBackend.demo.DTO.PositionDTOs.UniquePosition.ExtraInfoForUniquePositionDTO
import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import com.ClinicBackend.demo.Entities.ManagePositions.Limits
import com.ClinicBackend.demo.Entities.ManagePositions.PositionData
import com.ClinicBackend.demo.Entities.ManagePositions.UniquePosition
import com.ClinicBackend.demo.Repos.UniquePositionRepos
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.time.LocalDate
import java.time.temporal.ChronoUnit

@Service
class UniquePositionsService {

    @Autowired
    lateinit var uniquePositionRepos: UniquePositionRepos

    fun updateUniquePositionByCurrentPositions(currentPositions: List<CurrentPosition>){
        var uniquePosition = getUniquePositionByCurrentPosition(currentPositions.first())
        if(uniquePosition==null) uniquePosition= UniquePosition(currentPositions.first())
        val allLimits=currentPositions.flatMap { it.limits }
        var minDate: LocalDate = LocalDate.MAX
        var maxDate: LocalDate = LocalDate.MIN
        for(limit in allLimits){
            if(minDate>limit.startDate)minDate=limit.startDate!!
            if(maxDate<limit.endDate)maxDate=limit.endDate!!
        }
        val avgMin= MutableList(ChronoUnit.DAYS.between(minDate,maxDate).toInt()+1){0L}
        val avgMax= MutableList(ChronoUnit.DAYS.between(minDate,maxDate).toInt()+1){0L}
        val count= MutableList(ChronoUnit.DAYS.between(minDate,maxDate).toInt()+1){0L}
        for(limit in allLimits){
            for(date_ind in ChronoUnit.DAYS.between(minDate,limit.startDate).toInt()..
                    ChronoUnit.DAYS.between(minDate,limit.endDate).toInt()){
                avgMin[date_ind]=(avgMin[date_ind]*count[date_ind]+limit.min!!)/(count[date_ind]+1)
                avgMax[date_ind]=(avgMax[date_ind]*count[date_ind]+limit.max!!)/(count[date_ind]+1)
                ++count[date_ind]
            }
        }
        var lastAvgMin=avgMin[0]
        var lastAvgMax=avgMax[0]
        uniquePosition.limits.clear()
        var lastStartDate=0L
        for(ind in 0..ChronoUnit.DAYS.between(minDate,maxDate).toInt()){
            if(avgMin[ind]!=lastAvgMin || avgMax[ind]!=lastAvgMax){
                uniquePosition.limits+=Limits().also {
                    it.min=lastAvgMin
                    it.max=lastAvgMax
                    it.startDate=minDate.plusDays(lastStartDate)
                    it.endDate=minDate.plusDays(ind.toLong()-1)
                    it.positionToUniquePosition=uniquePosition
                }
                lastAvgMin=avgMin[ind]
                lastAvgMax=avgMax[ind]
                lastStartDate=ind.toLong()
            }
        }
        uniquePosition.limits+=Limits().also {
            it.min=lastAvgMin
            it.max=lastAvgMax
            it.startDate=minDate.plusDays(lastStartDate)
            it.endDate=minDate.plusDays(ChronoUnit.DAYS.between(minDate,maxDate) -1)
        }
        saveUniquePosition(uniquePosition)
    }

    fun getUniquePositions(companyName: String):List<UniquePosition>{
        return uniquePositionRepos.findByCompany_CompanyName(companyName)
    }

    fun getUniquePositionExtraData(uniquePositionId:Long,  companyName: String)
            : ExtraInfoForUniquePositionDTO {
        val uniquePosition=getUniquePositionById(uniquePositionId,companyName)
        val extraInfoForUniquePositionDTO= ExtraInfoForUniquePositionDTO(uniquePosition)
        return extraInfoForUniquePositionDTO
    }

    fun saveChangedUniquePositionByDTO(uniquePositionId: Long,
                                          newExtraInfoForUniquePositionDTO: ExtraInfoForUniquePositionDTO,
                                          companyName: String): ExtraInfoForUniquePositionDTO {
        val uniquePosition=getUniquePositionById(uniquePositionId,companyName)
        uniquePosition.limits.clear()
        uniquePosition.limits.addAll(
            newExtraInfoForUniquePositionDTO.limits.map {limit->limit.makeLimitsFromDTO()
                .also { it.positionToUniquePosition=uniquePosition } }
        )
        if(uniquePosition.attributes !=
            newExtraInfoForUniquePositionDTO.attributes.map { it.makeAttributeFromDTO() }.toSet()){
            uniquePosition.attributes.clear()
            uniquePosition.attributes.addAll(
                newExtraInfoForUniquePositionDTO.attributes
                    .map { attribute->
                        attribute.makeAttributeFromDTO().also { it.positionToUniquePosition = uniquePosition} }
            )
        }
        saveUniquePosition(uniquePosition)
        return ExtraInfoForUniquePositionDTO(uniquePosition)
    }

    fun getUniquePositionById(id:Long, companyName: String):UniquePosition{
        val uniquePosition=uniquePositionRepos.findById(id).orElseThrow()
        if(uniquePosition.company!!.companyName!=companyName)throw RuntimeException("You don't have access to positions" +
                "from another company")
        return uniquePosition
    }

    fun getUniquePositionByPositionData(positionData: PositionData)= uniquePositionRepos
        .findAllByCompany_CompanyNameAndName(
            positionData.loadedData!!.department!!.company!!.companyName!!,
            positionData.name!!
        ).firstOrNull { it.attributes == positionData.attributes }

    fun getUniquePositionByCurrentPosition(currentPosition: CurrentPosition)= uniquePositionRepos
        .findAllByCompany_CompanyNameAndName(
            currentPosition.department!!.company!!.companyName!!,
            currentPosition.name!!
        ).firstOrNull { it.attributes == currentPosition.attributes }

    fun saveUniquePosition(uniquePosition: UniquePosition){
        uniquePositionRepos.save(uniquePosition)
    }
}