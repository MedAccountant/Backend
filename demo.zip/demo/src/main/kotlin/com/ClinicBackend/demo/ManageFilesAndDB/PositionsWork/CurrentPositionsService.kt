package com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork

import com.ClinicBackend.demo.DAO.CompanyDAOImpl
import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.AttributeDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition.CurrentPositionStatDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition.ExtraInfoForCurrentPositionDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.LimitsDTO
import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManagePositions.*
import com.ClinicBackend.demo.ManageFilesAndDB.Exceptions.SavePositionException
import com.ClinicBackend.demo.Repos.ChangingPositionsRepos
import com.ClinicBackend.demo.Repos.CurrentPositionRepos
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.jvm.optionals.getOrNull

@Service
class CurrentPositionsService {

    @Autowired
    private lateinit var companyDAOImpl: CompanyDAOImpl

    @Autowired
    lateinit var currentPositionRepos: CurrentPositionRepos

    @Autowired
    lateinit var positionToBuyService:PositionsToBuyService

    @Autowired
    lateinit var changingPositionsRepos: ChangingPositionsRepos

    @Autowired
    lateinit var uniquePositionsService: UniquePositionsService

    @Autowired
    lateinit var positionDataDAO: PositionDataDAO

    fun checkPositionToBuy(currentPosition: CurrentPosition){
        val now = LocalDate.now()
        val currentLimits=currentPosition.limits.first { it.startDate!!<=now && now<=it.endDate!!}
        if(currentPosition.count!!<currentLimits.min!!){
            var positionToBuy=positionToBuyService.findByCurrentPosition(currentPosition)
            if(positionToBuy!=null)positionToBuy.countToBuy=currentLimits.max!!-currentPosition.count!!
            else positionToBuy = PositionToBuy().also {
                it.countToBuy=currentLimits.max!!-currentPosition.count!!
                it.currentPosition=currentPosition
            }
            positionToBuyService.savePositionToBuy(positionToBuy)
        }
    }

    fun getCurrentPositionsFromDepartmentsList(departments: List<Department>):List<CurrentPosition>{
        return departments.flatMap {department->
            department.currentPositions
        }.distinct()
    }

    //global current position management
    fun getCurrentPositionExtraDataGlobal(currentPositionId:Long, departments: List<Department>, companyName: String)
            : ExtraInfoForCurrentPositionDTO {
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        val equalPositions=getEqualCurrentPositions(requiredCurrentPosition,departments)
        val extraInfoForCurrentPositionDTO= ExtraInfoForCurrentPositionDTO()
        val limitDTOs=equalPositions.flatMap {
                position-> position.limits.map { limit->
            LimitsDTO(limit).also { it.department= DepartmentDTO(position.department!!) }
            }
        }.distinct()
        extraInfoForCurrentPositionDTO.limits=limitDTOs
        extraInfoForCurrentPositionDTO.attributes=requiredCurrentPosition.attributes.map { AttributeDTO(it) }
        extraInfoForCurrentPositionDTO.departmentsWherePositionOccurs=equalPositions
            .map { DepartmentDTO(it.department!!) }.distinct()
        return extraInfoForCurrentPositionDTO
    }

    fun saveChangedCurrentPositionsGlobal(currentPositionId: Long,
                                          departments: List<Department>,
                                          newExtraInfoForCurrentPositionDTO: ExtraInfoForCurrentPositionDTO,
                                          companyName: String): ExtraInfoForCurrentPositionDTO {
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        val equalPositions=getEqualCurrentPositions(requiredCurrentPosition,departments)
        for(department in departments){
            val limitsForDepartment=newExtraInfoForCurrentPositionDTO.limits
                .filter { getDepartmentFromCompany(it.department!!.departmentName!!,companyName)==department }
                .map { it.makeLimitsFromDTO() }
            val currentPositionFromDepartment=equalPositions.find { it.department==department }!!
            limitsForDepartment.forEach{it.positionToCurrentPosition=currentPositionFromDepartment}
            //check 365
            val limits=limitsForDepartment.sortedBy { it.startDate }
            if(limits.isEmpty()) throw SavePositionException("there is no limits")
            checkLimits(limits)

            currentPositionFromDepartment.limits.clear()
            currentPositionFromDepartment.limits.addAll(limitsForDepartment)
        }
        if(requiredCurrentPosition.attributes !=
            newExtraInfoForCurrentPositionDTO.attributes.map { it.makeAttributeFromDTO() }.toSet()){
            equalPositions.forEach { position->
                position.attributes.clear()
                position.attributes.addAll(newExtraInfoForCurrentPositionDTO.attributes
                    .map { attribute->
                        attribute.makeAttributeFromDTO().also { it.positionToCurrentPosition = position} })
            }
        }
        println("equals: ======================")
        equalPositions.forEach { println(it) }
        saveAllCurrentPositions(equalPositions)
        equalPositions.forEach { deleteCurrentPositionFromChangingPositionsIfExist(it) }
        return getCurrentPositionExtraDataGlobal(currentPositionId,departments,companyName)
    }


    //one department current position management

    fun getCurrentPositionExtraDataOneDep(currentPositionId:Long, department: Department, companyName: String)
            : ExtraInfoForCurrentPositionDTO {
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        val savedChanges=changingPositionsRepos.findByOldCurrentPosition(requiredCurrentPosition)
        val extraInfoForCurrentPositionDTO:ExtraInfoForCurrentPositionDTO
        if(savedChanges!=null){
            extraInfoForCurrentPositionDTO=ExtraInfoForCurrentPositionDTO(savedChanges.newCurrentPosition!!,
                requiredCurrentPosition.department!!)
            extraInfoForCurrentPositionDTO.changingMarker=true
        }
        else extraInfoForCurrentPositionDTO = ExtraInfoForCurrentPositionDTO(requiredCurrentPosition)
        extraInfoForCurrentPositionDTO.departmentsWherePositionOccurs= listOf(DepartmentDTO(department))
        return extraInfoForCurrentPositionDTO
    }

    fun updateLimitsAndAttributesCurrentPositionOneDep(currentPositionId: Long,
                                                       department: Department,
                                                       newExtraInfoForCurrentPositionDTO: ExtraInfoForCurrentPositionDTO,
                                                       companyName: String): ExtraInfoForCurrentPositionDTO {
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw PositionManagementException("There is no such current position with id: $currentPositionId")
        var savedChanges=changingPositionsRepos.findByOldCurrentPosition(requiredCurrentPosition)
        println("---------------------------------------------1")
        val newCurrentPosition:CurrentPosition
        if(savedChanges!=null){
            newCurrentPosition=savedChanges.newCurrentPosition!!
            newCurrentPosition.limits.clear()
            newCurrentPosition.attributes.clear()
        }
        else {
            savedChanges = ChangingPositions()
            newCurrentPosition=CurrentPosition()
            newCurrentPosition.department=requiredCurrentPosition.department
            savedChanges.newCurrentPosition=newCurrentPosition
            savedChanges.oldCurrentPosition=requiredCurrentPosition
        }
        println("---------------------------------------------2")
        val limits=newExtraInfoForCurrentPositionDTO.limits
            .filter { getDepartmentFromCompany(it.department!!.departmentName!!,companyName)==department }
            .map { limitDTO->limitDTO.makeLimitsFromDTO().also { it.positionToCurrentPosition=newCurrentPosition } }
        newCurrentPosition.limits.addAll(limits)
        newCurrentPosition.attributes.addAll(newExtraInfoForCurrentPositionDTO.attributes
            .map { attribute->
                attribute.makeAttributeFromDTO().also { it.positionToCurrentPosition = newCurrentPosition} })
        println("equals: ======================")
        println(newCurrentPosition)
        currentPositionRepos.save(newCurrentPosition)//save without checking positions to buy
        changingPositionsRepos.save(savedChanges)
        return getCurrentPositionExtraDataOneDep(currentPositionId,department,companyName)
    }

    fun saveChangedCurrentPositionOneDep(currentPositionId:Long,
                                   department: Department,
                                   companyName: String):Boolean{
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        val savedChanges=changingPositionsRepos.findByOldCurrentPosition(requiredCurrentPosition)
        val newCurrentPosition:CurrentPosition
        if(savedChanges!=null){
            newCurrentPosition=savedChanges.newCurrentPosition!!
            deleteCurrentPositionFromChangingPositionsIfExist(requiredCurrentPosition)
        }
        else {
            throw PositionManagementException("there is no changed version for position ${requiredCurrentPosition.name}")
        }
        val limits=newCurrentPosition.limits.sortedBy { it.startDate }
        if(limits.isEmpty()) throw SavePositionException("there is no limits")
        checkLimits(limits)
        requiredCurrentPosition.getLimitsAndAttributes(newCurrentPosition)
        saveCurrentPosition(requiredCurrentPosition,companyName)
        return true
    }

    fun getCurrentPositionStatistic(currentPositionId:Long,
                                    department: Department,
                                    companyName: String):CurrentPositionStatDTO{
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        return CurrentPositionStatDTO(positionDataDAO.getCurrentPositionStatistic(requiredCurrentPosition))
    }

    fun checkLimits(limits:List<Limits>){
        var daysCount:Int= ChronoUnit.DAYS.between(limits[0].startDate,limits[0].endDate).toInt()
        for(i in 1 until limits.size){
            if(limits[i-1].endDate!! !=  limits[i].startDate!!.minusDays(1))
                throw SavePositionException("There are limits with intersections or intervals between dates")
            daysCount+= ChronoUnit.DAYS.between(limits[i].startDate,limits[i].endDate).toInt()
        }
        if(daysCount<365)
            throw SavePositionException("Initialize limits for 365 days}")
    }

    fun saveCurrentPosition(currentPosition: CurrentPosition,companyName: String){
        currentPositionRepos.save(currentPosition)
        checkPositionToBuy(currentPosition)
        val equalPositions=getEqualCurrentPositions(currentPosition,
            companyDAOImpl.getDepartmentsFromCompany(companyName))
        uniquePositionsService.updateUniquePositionByCurrentPositions(equalPositions)
    }

    fun saveAllCurrentPositions(equalCurrentPositions: List<CurrentPosition>){
        currentPositionRepos.saveAll(equalCurrentPositions)
        equalCurrentPositions.forEach {
            checkPositionToBuy(it)
        }
        uniquePositionsService.updateUniquePositionByCurrentPositions(equalCurrentPositions)
    }

    fun getEqualCurrentPositions(currentPosition: CurrentPosition, departments: List<Department>):List<CurrentPosition>{
        return currentPositionRepos.findAllByNameAndDepartmentIn(currentPosition.name!!,
            departments.toSet()).filter {it.attributes==currentPosition.attributes}
    }

    fun getEqualCurrentPositions(positionData: PositionData, departments: List<Department>)=currentPositionRepos
        .findAllByNameAndDepartmentIn(
            positionData.name!!,
            departments.toSet()).filter {it.attributes==positionData.attributes}

    fun getDepartmentFromCompany(departmentName:String,companyName: String)=
        companyDAOImpl.getDepartmentByNameAndCompany(departmentName,companyName)

    fun deleteCurrentPositionFromChangingPositionsIfExist(currentPosition: CurrentPosition){
        val changingPositions=changingPositionsRepos.findByOldCurrentPosition(currentPosition)
        if(changingPositions!=null){
            changingPositionsRepos.delete(changingPositions)
            currentPositionRepos.delete(changingPositions.newCurrentPosition!!)
        }
    }
}