package com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition

import java.time.LocalDate

class CurrentPositionStatDTO() {
    var statistic:List<Pair<LocalDate,Long>> = listOf()
    constructor(stat:List<Pair<LocalDate,Long>>):this(){
        statistic=stat
    }
}