package com.ClinicBackend.demo.Service

import com.ClinicBackend.demo.DAO.CompanyDAOImpl
import com.ClinicBackend.demo.DAO.ComplaintsNRepliesDAO
import com.ClinicBackend.demo.DTO.CRDTOs.EditCnRDTO
import com.ClinicBackend.demo.Entities.ComplaintsNReplies
import com.ClinicBackend.demo.Entities.ManageUsers.User
import com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork.LoadedDataService
import org.springframework.beans.PropertyAccessException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ComplaintsNRepliesService {
    @Autowired
    private lateinit var complaintsNRepliesDAO: ComplaintsNRepliesDAO

    @Autowired
    private lateinit var companyDAOImpl: CompanyDAOImpl

    fun getThemes(user: User)=complaintsNRepliesDAO.getUserComplaints(user).map { it.theme }.toSet()

    fun getCRByTheme(user: User,theme:String)=complaintsNRepliesDAO.getUserComplaints(user).filter { it.theme==theme }

    fun getCRByIdToWatch(crId: Long,user: User)=complaintsNRepliesDAO.getCRByIdForUser(crId,user)

    fun getCRByIdForSender(crId:Long, user:User):ComplaintsNReplies{
        val cr=complaintsNRepliesDAO.getCRByIdForUser(crId,user)
        if(cr.sender==user)return cr
        else throw RuntimeException("User ${user.login!!} doesn't have access to complaint as sender with ID: $crId")
    }

    fun getCRByIdForRecipient(crId:Long, user:User):ComplaintsNReplies{
        val cr=complaintsNRepliesDAO.getCRByIdForUser(crId,user)
        if(cr.recipient==user || cr.recipientRole==user.role) return cr
        else throw RuntimeException("User ${user.login!!} doesn't have access to complaint as recipient with ID: $crId")
    }

    fun editCRById(crId: Long, editCnRDTO: EditCnRDTO, user:User):ComplaintsNReplies{
        val cr=getCRByIdForSender(crId,user)
        cr.closedMarker=editCnRDTO.closedMarker
        cr.theme=editCnRDTO.theme
        cr.complaint=editCnRDTO.complaint
        if(editCnRDTO.recipientRole!=null
            &&( editCnRDTO.recipientLogin==null || editCnRDTO.recipientLogin!!.isEmpty())){
            cr.recipientRole=editCnRDTO.recipientRole
            cr.recipient=null
        }
        else if(editCnRDTO.recipientRole==null
            && editCnRDTO.recipientLogin!=null
            && editCnRDTO.recipientLogin!!.isNotEmpty()){
            cr.recipient=companyDAOImpl.getUserByLogin(editCnRDTO.recipientLogin!!)?:
            throw RuntimeException("Recipient user with login ${editCnRDTO.recipientLogin} is not found")
            if(cr.recipient==user)throw RuntimeException("You can not send complaint to yourself")
            cr.recipientRole=null
        }
        else throw RuntimeException("only one, recipient role or recipient login should not be empty")
        complaintsNRepliesDAO.saveUpdatedCR(cr)
        return cr
    }

    fun replyOnComplaint(crId: Long, user: User, replyText:String):ComplaintsNReplies{
        val cr=getCRByIdForRecipient(crId,user)
        cr.reply=replyText
        cr.recipient=user
        complaintsNRepliesDAO.saveUpdatedCR(cr)
        return cr
    }

    fun createComplaint(editCnRDTO: EditCnRDTO, sender: User):ComplaintsNReplies{
        val newComplaintsNReplies=ComplaintsNReplies()
        newComplaintsNReplies.sender=sender
        newComplaintsNReplies.senderDepartments.addAll(sender.departments)
        newComplaintsNReplies.complaint=editCnRDTO.complaint
        if(editCnRDTO.recipientRole!=null
            &&( editCnRDTO.recipientLogin==null || editCnRDTO.recipientLogin!!.isEmpty())){
            newComplaintsNReplies.recipientRole=editCnRDTO.recipientRole
            newComplaintsNReplies.recipient=null
        }
        else if(editCnRDTO.recipientRole==null
            && editCnRDTO.recipientLogin!=null
            && editCnRDTO.recipientLogin!!.isNotEmpty()){
            newComplaintsNReplies.recipient=companyDAOImpl.getUserByLogin(editCnRDTO.recipientLogin!!)?:
                    throw RuntimeException("Recipient user with login ${editCnRDTO.recipientLogin} is not found")
            if(newComplaintsNReplies.recipient==sender)throw RuntimeException("You can not send complaint to yourself")
            newComplaintsNReplies.recipientRole=null
        }
        else throw RuntimeException("only one, recipient role or recipient login should not be empty")
        newComplaintsNReplies.theme=editCnRDTO.theme
        complaintsNRepliesDAO.saveUpdatedCR(newComplaintsNReplies)
        return newComplaintsNReplies
    }
}