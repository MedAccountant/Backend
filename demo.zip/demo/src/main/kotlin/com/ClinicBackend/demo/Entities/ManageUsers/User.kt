package com.ClinicBackend.demo.Entities.ManageUsers

import com.ClinicBackend.demo.Entities.ComplaintsNReplies
import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManageLoadedData.LoadedData
import com.ClinicBackend.demo.Entities.Order
import jakarta.persistence.*

@Entity
@Table(name="users")
open class User() {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "user_id")
    open var userId:Long?=null

    @Column(length = 40, unique = true)
    open var login: String? = null

    @Column(nullable = false, length = 40)
    open var nickname: String? = null

    @Column()
    @Enumerated(EnumType.STRING)
    open var role: Role?=null

    @Column(length = 100)
    open var password:String?=null

    //orders---------------------
    @OneToMany(mappedBy = "sender")
    open var sentOrders=mutableSetOf<Order>()

    @OneToMany(mappedBy = "editedBy")
    open var editedOrders=mutableSetOf<Order>()

    @OneToMany(mappedBy = "complaintBy")
    open var complaintOrders=mutableSetOf<Order>()

    @OneToMany(mappedBy = "doneBy")
    open var doneOrders=mutableSetOf<Order>()

    //loaded data----------------
    @OneToMany(mappedBy = "sender")
    open var loadedDataOfUser=mutableSetOf<LoadedData>()


    //departments---------------
    @ManyToMany
    @JoinTable (name="user_department",
        joinColumns=[JoinColumn (name="user_id")],
        inverseJoinColumns=[JoinColumn(name="department_id")])
    open var departments= mutableSetOf<Department>()

    //complaint/replies----------
    @OneToMany(mappedBy = "sender"/*,cascade = [(CascadeType.ALL)]*/)
    open var sentComplaints=mutableSetOf<ComplaintsNReplies>()

    @OneToMany(mappedBy = "sender"/*,cascade = [(CascadeType.ALL)]*/)
    open var repliedComplaints=mutableSetOf<ComplaintsNReplies>()

    fun editUser(newUser: User){
        newUser.login?.let { login=it }
        //login=newUser.login
        newUser.nickname?.let { nickname=it }
        //nickname=newUser.nickname
        newUser.role?.let { role=it }
        //role=newUser.role
        departments=newUser.departments
        newUser.password?.let { password=it }
        //password=newUser.password
    }

    fun getWorkingDepartments()=departments.filter { it.workingMarker!! }.toMutableSet()

    fun removeDepartment(department: Department) {
        departments.remove(department)
        //println("removeDepartment, removed from departments")
    }

    @PreRemove
    private fun removeAssociationsWithChilds() {
        sentOrders.forEach { it.sender=null }
        editedOrders.forEach { it.editedBy=null }
        complaintOrders.forEach { it.complaintBy=null }
        doneOrders.forEach { it.doneBy=null }
        loadedDataOfUser.forEach { it.sender=null }
        departments.forEach { it.users.remove(this) }
        departments.clear()
        sentComplaints.forEach { it.sender=null }
        repliedComplaints.forEach { it.recipient=null }
    }

    override fun toString():String{
        var departmentsString=""
        departments!!.forEach {departmentsString+=it.toString() +",\n"}
        return  "{\n" +
                "\"login\":$login \n" +
                "\"nickname\":$nickname \n" +
                "\"role\":$role \n" +
                "\"password\":$password \n" +
                "\"departments\":[\n" +
                departmentsString+
                "\n]\n" +
                "}"
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is User) return false

        if (login != other.login) return false

        return true
    }

    override fun hashCode(): Int {
        return login?.hashCode() ?: 0
    }
}