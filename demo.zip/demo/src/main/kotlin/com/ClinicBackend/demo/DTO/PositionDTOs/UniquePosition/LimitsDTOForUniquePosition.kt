package com.ClinicBackend.demo.DTO.PositionDTOs.UniquePosition

import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.LimitsDTO
import com.ClinicBackend.demo.Entities.ManagePositions.Limits
import com.fasterxml.jackson.annotation.JsonFormat
import java.time.LocalDate

class LimitsDTOForUniquePosition() {
    var min:Long?=null
    var max:Long?=null
    @JsonFormat(pattern="yyyy-MM-dd")
    var startDate: LocalDate?=null
    @JsonFormat(pattern="yyyy-MM-dd")
    var endDate: LocalDate?=null

    constructor(limits: Limits):this(){
        min=limits.min
        max=limits.max
        startDate=limits.startDate
        endDate=limits.endDate
    }
    fun makeLimitsFromDTO(): Limits {
        val newLimits= Limits()
        newLimits.min=min
        newLimits.max=max
        newLimits.startDate=startDate
        newLimits.endDate=endDate
        return newLimits
    }

    override fun toString():String{
        return  "{\n" +
                "\"min\":$min \n" +
                "\"max\":$max \n" +
                "\"startDate\":$startDate \n" +
                "\"endDate\":$endDate \n" +
                "\n}"
    }
}