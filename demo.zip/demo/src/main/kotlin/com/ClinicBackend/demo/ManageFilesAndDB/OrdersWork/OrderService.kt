package com.ClinicBackend.demo.ManageFilesAndDB.OrdersWork

import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.Order
import com.ClinicBackend.demo.Entities.ManagePositions.PositionToBuy
import com.ClinicBackend.demo.Entities.ManageUsers.Role
import com.ClinicBackend.demo.Entities.ManageUsers.User
import com.ClinicBackend.demo.ManageFilesAndDB.FileSystemStorageService
import com.ClinicBackend.demo.Repos.SupplierRepos
import com.ClinicBackend.demo.Service.EmailService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.io.UrlResource
import org.springframework.stereotype.Service
import org.springframework.web.multipart.MultipartFile
import java.time.LocalDate

@Service
class OrderService() {

    @Autowired
    private lateinit var orderDAO: OrderDAO

    @Autowired
    private lateinit var fileSystemStorageService: FileSystemStorageService

    @Autowired
    private lateinit var supplierRepos: SupplierRepos

    @Autowired
    private lateinit var emailService:EmailService

    fun getOrdersFromDepartment(department:Department)=orderDAO.getOrdersFromDepartment(department)

    fun getOrdersForDP(department: Department)=orderDAO.getOrdersFromDepartmentForDP(department)

    fun getOrderByName(name:String, department: Department,role: Role): Order?{
        //add department check!!!
        return orderDAO.getOrderByName("$name.xlsx", department,role)
    }

    fun createOrder(positionsToBuy:List<PositionToBuy>){
        val nowDate= LocalDate.now()
        val newFileName="${nowDate.dayOfMonth}.${nowDate.monthValue}.${nowDate.year} Заказ от" +
                " ${positionsToBuy.first().currentPosition!!.department!!.departmentName}.xlsx"
        val linkToOrderFile=fileSystemStorageService.createOrderFile(positionsToBuy,newFileName)
        orderDAO.createOrder(linkToOrderFile,positionsToBuy.first().currentPosition!!.department!!)
    }

    fun setNewDescriptionToOrder(name:String, department: Department,user: User, newDescription:String): Order {
        val order = orderDAO.getOrderByName("$name.xlsx", department, user.role!!)
        order!!.description=newDescription
        order.editedMarker=true
        order.editedBy=user
        if(order.complaintDescription!=null && order.complaintDescription!!.isNotEmpty()){
            order.readMarkerEditor=false
            order.badOrderMarker=false
        }
        orderDAO.saveUpdatedOrder(order)
        return order
    }

    fun setNewOrderFile(file: MultipartFile, name:String, department: Department, user: User): Order {
        val order = orderDAO.getOrderByName("$name.xlsx", department, user.role!!)
        order!!.linkToFile=fileSystemStorageService.updateOrderFile(file)
        order.editedMarker=true
        order.editedBy=user
        if(order.complaintDescription!=null && order.complaintDescription!!.isNotEmpty()){
            order.readMarkerEditor=false
            order.badOrderMarker=false
        }
        orderDAO.saveUpdatedOrder(order)
        return order
    }

    fun loadOrderFileByNameAsResource(fileName:String,department: Department,role: Role):UrlResource{
        val order = orderDAO.getOrderByName("$fileName.xlsx", department, role)
        val name=order!!.linkToFile!!.substringAfterLast("\\")
        return fileSystemStorageService.loadAsResource(name)
    }

    fun verifyOrder(name:String, department: Department, user:User): Order {
        val order = orderDAO.getOrderByName("$name.xlsx", department, user.role!!)
        order!!.verifiedMarker=true
        order.sender=user
        order.readMarkerDP=false
        orderDAO.saveUpdatedOrder(order)
        return order
    }

    fun sendOrder(name: String, email: String, sender: User){
        println("send order:$name from ${sender.login} to $email")
        val order = orderDAO.getOrderByName("$name.xlsx", sender.departments.first(), sender.role!!)?:
            throw RuntimeException("Order with name $name doesn't exist or you don't have access to one")
        val supplier=supplierRepos.findByEmail(email)?:throw RuntimeException("There is no supplier with email: $email")
        emailService.sendMessageWithAttachment(
            email,
            "New $name from ${sender.departments.first().departmentName} (${sender.nickname})",
            order.description?:"",
            order.linkToFile!!
            )
        order.sentTo=supplier
        order.doneBy=sender
        order.doneOrderMarker=true
        orderDAO.saveUpdatedOrder(order)
    }

    fun challengeOrder(complaintDescription:String, name:String, user:User){
        val order = orderDAO.getOrderByName("$name.xlsx", user.departments.first(), user.role!!)
        order!!.complaintDescription=complaintDescription
        order.verifiedMarker=false
        order.badOrderMarker=true
        order.complaintBy=user
        order.readMarkerEditor=false
        orderDAO.saveUpdatedOrder(order)
    }
}