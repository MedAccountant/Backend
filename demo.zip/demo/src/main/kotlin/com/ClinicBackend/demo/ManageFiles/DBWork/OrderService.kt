package com.ClinicBackend.demo.ManageFiles.DBWork

import com.ClinicBackend.demo.Entities.ManageOrders.Order
import com.ClinicBackend.demo.Entities.ManagePositions.PositionToBuy
import com.ClinicBackend.demo.ManageFiles.Exceptions.StorageException
import com.ClinicBackend.demo.ManageFiles.FileSystemStorageService
import com.ClinicBackend.demo.ManageFiles.StorageProperties
import com.ClinicBackend.demo.Repos.OrderRepos
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import org.springframework.util.FileSystemUtils
import org.springframework.web.multipart.MultipartFile
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption
import java.time.LocalDate
import kotlin.io.path.pathString

@Service
class OrderService(@Autowired
                   private var properties: StorageProperties) {

    @Autowired
    private lateinit var orderRepos: OrderRepos

    @Autowired
    private lateinit var fileSystemStorageService: FileSystemStorageService

    fun saveOrder(positionsToBuy:List<PositionToBuy>){
        positionsToBuy.forEach { println(it) }
        println("saveOrder")
        val nowDate= LocalDate.now()
        val newFileName="${nowDate.dayOfMonth}.${nowDate.monthValue}.${nowDate.year} Заказ от" +
                " ${positionsToBuy.first().currentPosition!!.department!!.departmentName}.xlsx"
        val linkToOrderFile=fileSystemStorageService.createOrderFile(positionsToBuy,newFileName)
        orderRepos.save(Order(linkToOrderFile,positionsToBuy.first().currentPosition!!.department!!))
    }


}