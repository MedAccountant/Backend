package com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork

open class PositionManagementException: RuntimeException {
    constructor(message: String?) : super(message)
    constructor(message: String?, cause: Throwable?) : super(message, cause)
}