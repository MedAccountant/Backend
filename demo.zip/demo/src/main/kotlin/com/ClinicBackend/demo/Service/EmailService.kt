package com.ClinicBackend.demo.Service

import jakarta.mail.internet.InternetAddress
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.core.io.FileSystemResource
import org.springframework.mail.javamail.JavaMailSender
import org.springframework.mail.javamail.MimeMessageHelper
import org.springframework.stereotype.Component
import java.io.File


@Component
class EmailService {
    @Autowired
    lateinit private var emailSender: JavaMailSender

    @Value("\${spring.mail.sender.email}")
    lateinit private var senderEmail: String

    @Value("\${spring.mail.sender.text}")
    lateinit private var senderText: String

    fun sendMessageWithAttachment(
        sendTo: String, subject: String, description:String, pathToOrderFile: String
    ) {
        //println("send to $sendTo, subject: $subject, description: $description, \n path: $pathToOrderFile")
        val message = emailSender.createMimeMessage()
        val helper = MimeMessageHelper(message, true)
        helper.setFrom(InternetAddress(senderEmail, senderText))
        helper.setTo(sendTo)
        helper.setText(description)
        helper.setSubject(subject)
        val file = FileSystemResource(File(pathToOrderFile))
        helper.addAttachment(pathToOrderFile.substringAfterLast("\\"), file)
        emailSender.send(message)
    }
}