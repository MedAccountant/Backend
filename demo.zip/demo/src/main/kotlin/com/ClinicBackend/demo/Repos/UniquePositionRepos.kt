package com.ClinicBackend.demo.Repos

import com.ClinicBackend.demo.Entities.Company
import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import com.ClinicBackend.demo.Entities.ManagePositions.PositionAttribute
import com.ClinicBackend.demo.Entities.ManagePositions.UniquePosition
import org.springframework.data.jpa.repository.EntityGraph
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface UniquePositionRepos: JpaRepository<UniquePosition, Long> {
    fun findByCompany_CompanyName(companyName:String):List<UniquePosition>

    @EntityGraph(attributePaths = ["attributes","limits"])
    fun findAllByCompany_CompanyNameAndName
                (companyName: String, name:String):List<UniquePosition>
}