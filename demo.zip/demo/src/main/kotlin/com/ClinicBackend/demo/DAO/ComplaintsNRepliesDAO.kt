package com.ClinicBackend.demo.DAO

import com.ClinicBackend.demo.Entities.ComplaintsNReplies
import com.ClinicBackend.demo.Entities.ManageUsers.User
import com.ClinicBackend.demo.Repos.ComplaintsNRepliesRepos
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class ComplaintsNRepliesDAO() {
    @Autowired
    private lateinit var complaintsNRepliesRepos: ComplaintsNRepliesRepos

    fun getUserComplaints(user: User):List<ComplaintsNReplies> {
        val departments=user.getWorkingDepartments()
//        println("departments: ")
//        departments.forEach{println(it)}
        return complaintsNRepliesRepos
            .findCRsForUser(
                departments = departments,
                recRole = user.role!!,
                sender = user,
                recipient = user
                )
    }

    fun getCRByIdForUser(crId: Long, user: User): ComplaintsNReplies {
        val departments = user.getWorkingDepartments()
        return complaintsNRepliesRepos
            .findCRByIdForUser(
                crId = crId,
                departments = departments,
                recRole = user.role!!,
                sender = user,
                recipient = user
            ) ?: throw RuntimeException("There is no such complaint with ID: $crId, or You don't have access to one")
    }

    fun saveUpdatedCR(cr:ComplaintsNReplies)=complaintsNRepliesRepos.save(cr)
}