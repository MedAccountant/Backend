package com.ClinicBackend.demo.Repos

import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.Order
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface OrderRepos: JpaRepository<Order, Long> {
    fun findByLinkToFileEndsWith(fileName:String): Order?
    fun findByDepartmentEquals(department: Department):List<Order>

    //done=false and (badOrder=true or verified=true)
    fun findByDepartmentEqualsAndDoneOrderMarkerEqualsAndVerifiedMarkerEqualsOrDepartmentEqualsAndDoneOrderMarkerEqualsAndBadOrderMarkerEquals(
        department1: Department,
        doneOrderMarker1:Boolean=false,
        verifiedMarker:Boolean=true,
        department2: Department,
        doneOrderMarker2:Boolean=false,
        badOrderMarker:Boolean=true
        ):List<Order>
}