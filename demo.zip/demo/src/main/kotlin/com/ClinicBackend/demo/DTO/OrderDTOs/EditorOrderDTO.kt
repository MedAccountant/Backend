package com.ClinicBackend.demo.DTO.OrderDTOs

import com.ClinicBackend.demo.Entities.Order

class EditorOrderDTO() {
    var orderName: String? = null
    var editedMarker=false
    var verifiedMarker=false
    var badOrderMarker=false
    var readMarker=false
    var doneOrderMarker=false

    constructor(order: Order):this(){
        orderName=order.linkToFile!!.substringAfterLast("\\").substringBeforeLast(".xlsx")
        editedMarker=order.editedMarker
        verifiedMarker=order.verifiedMarker
        badOrderMarker=order.badOrderMarker
        readMarker=order.readMarkerEditor
        doneOrderMarker=order.doneOrderMarker
    }

    override fun toString(): String {
        return "DataProducerOrderDTO(orderName=$orderName, editedMarker=$editedMarker, verifiedMarker=$verifiedMarker, badOrderMarker=$badOrderMarker, readMarker=$readMarker, doneOrderMarker=$doneOrderMarker)"
    }


}