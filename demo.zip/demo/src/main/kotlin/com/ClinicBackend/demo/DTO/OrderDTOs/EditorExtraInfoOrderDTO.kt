package com.ClinicBackend.demo.DTO.OrderDTOs

import com.ClinicBackend.demo.Entities.Order

class EditorExtraInfoOrderDTO() {
    var description:String?=null
    var complaintDescription:String?=null
    var senderLogin:String?=null
    var sentToEmail:String?=null
    var editedByLogin:String?=null
    var complaintByLogin:String?=null
    var doneByLogin:String?=null

    constructor(order: Order):this(){
        description=order.description
        complaintDescription=order.complaintDescription
        senderLogin=order.sender?.login
        sentToEmail=order.sentTo?.email
        editedByLogin=order.editedBy?.login
        complaintByLogin=order.complaintBy?.login
        doneByLogin=order.doneBy?.login
    }

    override fun toString(): String {
        return "EditorExtraInfoOrderDTO(description=$description, complaintDescription=$complaintDescription, senderLogin=$senderLogin, sentToEmail=$sentToEmail, editedByLogin=$editedByLogin, complaintByLogin=$complaintByLogin, doneByLogin=$doneByLogin)"
    }


}